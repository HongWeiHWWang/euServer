﻿using Flowable.Common.Models;
using Flowable.Common.Web.Client;
using Flowable.Common.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Flowable.Common
{
    /// <summary>
    /// Flowable工作流帮助类
    /// </summary>
    public static class FlowableHelper
    {
        /// <summary>
        /// Flowable根地址Url
        /// </summary>
        public static string BaseUrl = ConfigurationManager.AppSettings["Flowable.BaseUrl"];

        /// <summary>
        /// Flowable管理员账号
        /// </summary>
        public static string AdminUserName = ConfigurationManager.AppSettings["Flowable.AdminUserName"];

        /// <summary>
        /// Flowable管理员密码
        /// </summary>
        public static string AdminPassword = ConfigurationManager.AppSettings["Flowable.AdminPassword"];

        /// <summary>
        /// Flowable是否自动创建用户
        /// </summary>
        public static string IsAutoCreateUser = ConfigurationManager.AppSettings["Flowable.IsAutoCreateUser"];

        /// <summary>
        /// Flowable默认用户密码
        /// </summary>
        public static string DefaultUserPassword = ConfigurationManager.AppSettings["Flowable.DefaultUserPassword"];

        /// <summary>
        /// Flowable默认邮箱后缀
        /// </summary>
        public static string DefaultEmailSuffix = ConfigurationManager.AppSettings["Flowable.DefaultEmailSuffix"];

        /// <summary>
        /// 获取Flowable接口的Token
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private static string GetToken(string userName, string password = "")
        {
            //用户名统一小写
            userName = userName.ToLower();

            if (string.IsNullOrEmpty(password)) password = DefaultUserPassword;

            return string.Format("Basic {0}",
            Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", userName, password))));
        }

        /// <summary>
        /// 获取Flowable接口的管理员Token
        /// </summary>
        /// <returns></returns>
        private static string GetAdminToken => GetToken(AdminUserName, AdminPassword);

        /// <summary>
        /// 引擎信息
        /// </summary>
        /// <returns></returns>
        public static string EngineInfo()
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/management/engine", Method.GET)
                .AddHeader("Authorization", GetAdminToken)
                .Execute()
                .ThrowIfError()
                .Content;

            return result;
        }

        /// <summary>
        /// 部署流程定义
        /// </summary>
        /// <param name="filePath">流程定义的xml文件路径</param>
        /// <returns></returns>
        public static AjaxResponse<DeploymentProcessOutput> DeploymentProcess(string filePath)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/repository/deployments")
                .AddHeader("Authorization", GetAdminToken)
                .AddFile(Path.GetFileName(filePath), filePath)
                .Execute()
                .ThrowIfError()
                .AjaxResponse<DeploymentProcessOutput>();

            return result;
        }

        /// <summary>
        /// 部署流程定义
        /// </summary>
        /// <param name="fileName">流程定义的xml文件名称</param>
        /// <param name="fileContent">流程定义的xml文件内容的字节数组</param>
        /// <returns></returns>
        public static AjaxResponse<DeploymentProcessOutput> DeploymentProcess(string fileName, byte[] fileContent)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/repository/deployments")
                .AddHeader("Authorization", GetAdminToken)
                .AddFileBytes(fileName, fileContent, fileName)
                .Execute()
                .ThrowIfError()
                .AjaxResponse<DeploymentProcessOutput>();

            return result;
        }

        /// <summary>
        /// 启动工作流
        /// </summary>
        /// <param name="start"></param>
        /// <returns></returns>
        public static AjaxResponse<StartProcessOutput> StartProcess(StartProcessInput start)
        {
            //校验用户
            if (!CheckUserExist(start.Operator).Success)
            {
                return new AjaxResponse<StartProcessOutput>
                {
                    Success = false,
                    Error = new ErrorInfo { Code = "401", Message = "Unauthorized" }
                };
            }

            //启动流程
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/runtime/process-instances")
                .AddHeader("Authorization", GetToken(start.Operator))
                .AddJsonBody(new FlowableStartProcessInput
                {
                    processDefinitionKey = start.ProcessKey,
                    businessKey = start.BusinessId,
                    variables = start.Variables.Select(x => new FlowableProcessVariable
                    {
                        name = x.Name,
                        value = x.Value
                    }).ToList()
                })
                .Execute()
                .ThrowIfError()
                .AjaxResponse<FlowableStartProcessOutput>();

            //获取代办
            List<QueryTaskOutput> taskList = null;
            if (start.IsReturnTask && result.Result != null)
            {
                var taskResult = QueryTasksByProcessId(result.Result.id);
                if (taskResult.Success) taskList = taskResult.Result;
            }

            //获取流程定义
            var processDefinitionResult = QueryProcessDefinition(result.Result.processDefinitionId);

            return new AjaxResponse<StartProcessOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Result == null ? null : new StartProcessOutput
                {
                    ProcessId = result.Result.id,
                    ProcessDefinitionId = result.Result.processDefinitionId,
                    TaskList = taskList,
                    ProcessDefinition = processDefinitionResult.Result
                }
            };
        }

        /// <summary>
        /// 查询流程实例
        /// </summary>
        /// <param name="processId"></param>
        /// <param name="isReturnTask"></param>
        /// <returns></returns>
        public static AjaxResponse<QueryProcessOutput> QueryProcess(string processId, bool isReturnTask = true)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/history/historic-process-instances/" + processId, Method.GET)
                 .AddHeader("Authorization", GetAdminToken)
                 .Execute()
                 .ThrowIfError()
                 .AjaxResponse<FlowableQueryProcessOutput>();

            //获取已有代办列表
            List<QueryHistoricTaskOutput> taskList = null;
            if (isReturnTask)
            {
                var taskResult = QueryHistoricTask(processId);
                if (taskResult.Success) taskList = taskResult.Result;
            }

            //设置当前节点Key
            var currentActivityKey = string.Empty;
            if (result.Result != null)
            {
                //流程结束时间有值代表流程结束
                if (result.Result.endTime.HasValue)
                {
                    currentActivityKey = "End";
                }
                else
                {
                    if (taskList != null && taskList.Count > 0)
                    {
                        //获取当前代办，代办结束时间无值代表当前代办
                        var currentTask = taskList.FirstOrDefault(x => !x.EndTime.HasValue);
                        if (currentTask != null)
                        {
                            currentActivityKey = currentTask.Key;
                        }
                    }
                }
            }

            //获取流程定义
            var processDefinitionResult = QueryProcessDefinition(result.Result.processDefinitionId);

            return new AjaxResponse<QueryProcessOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Result == null ? null : new QueryProcessOutput
                {
                    ProcessId = result.Result.id,
                    BusinessId = result.Result.businessKey,
                    ProcessDefinitionId = result.Result.processDefinitionId,
                    ProcessName = result.Result.processDefinitionName,
                    StartTime = result.Result.startTime,
                    EndTime = result.Result.endTime,
                    StartUserName = result.Result.startUserId,
                    CurrentActivityKey = currentActivityKey,
                    HistoricTaskList = taskList,
                    ProcessDefinition = processDefinitionResult.Result
                }
            };
        }

        /// <summary>
        /// 终止流程
        /// </summary>
        /// <param name="operatorUserName"></param>
        /// <param name="processId"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public static AjaxResponse<QueryProcessOutput> AbortProcess(string operatorUserName, string processId, string reason)
        {
            //获取所有当前流程代办
            var tasks = QueryTasksByProcessId(processId);

            if (tasks.Result != null && tasks.Result.Count > 0)
            {
                //根据操作人，匹配一下对应的代办
                var task = tasks.Result.Where(x => x.UserName.ToLower() == operatorUserName.ToLower()).FirstOrDefault();
                //如果没有找到对应代办，则使用第一个代办代替
                if (task == null) task = tasks.Result[0];

                //插入一个代办原因
                InsertTaskComment(operatorUserName, task.TaskId, reason);

                var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/runtime/process-instances/" + processId + "/change-state")
                .AddHeader("Authorization", GetAdminToken)
                .AddJsonBody(new
                {
                    //将所有代办节点流转到结束
                    cancelActivityIds = tasks.Result.Select(x => x.Key).ToArray(),
                    startActivityIds = new string[] { "End" }
                })
                .Execute()
                .ThrowIfError()
                .AjaxResponse();

                //获取流程实例（不需要返回历史代办）
                var processResult = QueryProcess(processId, isReturnTask: false);

                //把终止流程前的当前代办数据整理并返回（去除当前终止人代办）
                processResult.Result.HistoricTaskList = tasks.Result.Where(x => x.UserName.ToLower() != operatorUserName.ToLower()).Select(x => new QueryHistoricTaskOutput
                {
                    TaskId = x.TaskId,
                    Key = x.Key,
                    Name = x.Name,
                    UserName = x.UserName,
                    StartTime = x.CreateTime,
                    EndTime = DateTime.Now
                }).ToList();

                return new AjaxResponse<QueryProcessOutput>
                {
                    Success = result.Success,
                    Error = result.Error,
                    Result = processResult.Result == null ? null : processResult.Result
                };
            }

            return new AjaxResponse<QueryProcessOutput>
            {
                Success = false,
                Error = new ErrorInfo { Code = "404", Message = "Not Found Tasks" },
                Result = null
            };
        }

        /// <summary>
        /// 删除流程
        /// </summary>
        /// <param name="processId"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public static AjaxResponse<bool> DeleteProcess(string processId, string reason)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/runtime/process-instances/" + processId + "?deleteReason=" + reason, Method.DELETE)
                .AddHeader("Authorization", GetAdminToken)
                .Execute()
                .ThrowIfError()
                .AjaxResponse();

            return new AjaxResponse<bool>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Success
            };
        }

        /// <summary>
        /// 流程节点跳转
        /// </summary>
        /// <param name="processId">流程Id</param>
        /// <param name="currentActivityKey">当前节点Key</param>
        /// <param name="targetActivityKey">目标节点Key</param>
        /// <param name="reason">原因</param>
        /// <returns></returns>
        public static AjaxResponse<bool> ProcessActivityJump(string processId, string currentActivityKey, string targetActivityKey, string reason)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/runtime/process-instances/" + processId + "/change-state")
                 .AddHeader("Authorization", GetAdminToken)
                 .AddJsonBody(new
                 {
                     cancelActivityIds = new string[] { currentActivityKey },
                     startActivityIds = new string[] { targetActivityKey }
                 })
                 .Execute()
                 .ThrowIfError()
                 .AjaxResponse();

            return new AjaxResponse<bool>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Success
            };
        }

        /// <summary>
        /// 查询代办(支持：用户名、流程Key、分页)
        /// </summary>
        /// <param name="query"></param>
        public static AjaxResponse<QueryTaskPagedOutput> QueryTasksPaged(QueryTaskPagedInput query)
        {
            //查询代办，用户名和流程Key没有值，必须置为null
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/query/tasks")
                .AddHeader("Authorization", GetAdminToken)
                .AddJsonBody(new FlowableQueryTaskPagedInput
                {
                    start = (query.PageIndex - 1) * query.PageSize,
                    size = query.PageSize,
                    assignee = string.IsNullOrEmpty(query.UserName) ? null : query.UserName,
                    processDefinitionKey = string.IsNullOrEmpty(query.ProcessKey) ? null : query.ProcessKey
                })
                .Execute()
                .ThrowIfError()
                .AjaxResponse<FlowableQueryTaskOutput>();

            return new AjaxResponse<QueryTaskPagedOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.total == 0) ? null : new QueryTaskPagedOutput
                {
                    Total = result.Result.total,
                    Data = result.Result.data.Select(x => new QueryTaskOutput
                    {
                        TaskId = x.id,
                        UserName = x.assignee,
                        ProcessId = x.processInstanceId,
                        Name = x.name,
                        Key = x.taskDefinitionKey,
                        ProcessDefinitionId = x.processDefinitionId,
                        CreateTime = x.createTime
                    }).ToList()
                }
            };
        }

        /// <summary>
        /// 根据用户名，查询代办
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <returns></returns>
        public static AjaxResponse<List<QueryTaskOutput>> QueryTasksByUserName(string userName)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/query/tasks")
                .AddHeader("Authorization", GetAdminToken)
                .AddJsonBody(new { assignee = userName })
                .Execute()
                .ThrowIfError()
                .AjaxResponse<FlowableQueryTaskOutput>();

            return new AjaxResponse<List<QueryTaskOutput>>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.data == null) ? null : result.Result.data.Select(x => new QueryTaskOutput
                {
                    TaskId = x.id,
                    UserName = x.assignee,
                    ProcessId = x.processInstanceId,
                    Name = x.name,
                    Key = x.taskDefinitionKey,
                    ProcessDefinitionId = x.processDefinitionId,
                    CreateTime = x.createTime
                }).ToList()
            };
        }

        /// <summary>
        /// 根据流程Id，查询代办
        /// </summary>
        /// <param name="processId">流程Id</param>
        /// <returns></returns>
        public static AjaxResponse<List<QueryTaskOutput>> QueryTasksByProcessId(string processId)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/query/tasks")
                .AddHeader("Authorization", GetAdminToken)
                .AddJsonBody(new { processInstanceId = processId })
                .Execute()
                .ThrowIfError()
                .AjaxResponse<FlowableQueryTaskOutput>();

            return new AjaxResponse<List<QueryTaskOutput>>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.data == null) ? null : result.Result.data.Select(x => new QueryTaskOutput
                {
                    TaskId = x.id,
                    UserName = x.assignee,
                    ProcessId = x.processInstanceId,
                    Name = x.name,
                    Key = x.taskDefinitionKey,
                    ProcessDefinitionId = x.processDefinitionId,
                    CreateTime = x.createTime
                }).ToList()
            };
        }

        /// <summary>
        /// 根据流程Key，查询代办
        /// </summary>
        /// <param name="processKey">流程Key</param>
        /// <returns></returns>
        public static AjaxResponse<List<QueryTaskOutput>> QueryTasksByProcessKey(string processKey)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/query/tasks")
                .AddHeader("Authorization", GetAdminToken)
                .AddJsonBody(new { processDefinitionKey = processKey })
                .Execute()
                .ThrowIfError()
                .AjaxResponse<FlowableQueryTaskOutput>();

            return new AjaxResponse<List<QueryTaskOutput>>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.data == null) ? null : result.Result.data.Select(x => new QueryTaskOutput
                {
                    TaskId = x.id,
                    UserName = x.assignee,
                    ProcessId = x.processInstanceId,
                    Name = x.name,
                    Key = x.taskDefinitionKey,
                    ProcessDefinitionId = x.processDefinitionId,
                    CreateTime = x.createTime
                }).ToList()
            };
        }

        /// <summary>
        /// 审批
        /// </summary>
        /// <param name="approve"></param>
        /// <returns></returns>
        public static AjaxResponse<ApproveOutput> Approve(ApproveInput approve)
        {
            //校验用户
            if (!CheckUserExist(approve.Operator).Success)
            {
                return new AjaxResponse<ApproveOutput>
                {
                    Success = false,
                    Error = new ErrorInfo { Code = "401", Message = "Unauthorized" }
                };
            }

            //整理变量参数
            if (approve.Variables == null) approve.Variables = new List<ProcessVariable>();

            var variables = approve.Variables.Select(x => new FlowableProcessVariable
            {
                name = x.Name,
                value = x.Value
            }).ToList();

            //强制写入一个 审批同意 变量
            variables.Add(new FlowableProcessVariable { name = "_IsApproved", value = true });

            //插入代办评论
            InsertTaskComment(approve.Operator, approve.TaskId, approve.Reason);

            //完成审批
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/runtime/tasks/" + approve.TaskId)
               .AddHeader("Authorization", GetToken(approve.Operator))
                .AddJsonBody(new
                {
                    action = "complete",
                    variables
                })
                .Execute()
                .ThrowIfError()
                .AjaxResponse();

            //获取代办
            List<QueryTaskOutput> taskList = null;
            if (approve.IsReturnTask && result.Success)
            {
                var taskResult = QueryTasksByProcessId(approve.ProcessId);
                if (taskResult.Success) taskList = taskResult.Result;
            }

            //获取流程实例（不需要返回历史代办）
            var processResult = QueryProcess(approve.ProcessId, isReturnTask: false);

            return new AjaxResponse<ApproveOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = !result.Success ? null : new ApproveOutput
                {
                    ProcessId = approve.ProcessId,
                    BusinessId = (processResult.Success && processResult.Result != null) ? processResult.Result.BusinessId : null,
                    ProcessName = (processResult.Success && processResult.Result != null) ? processResult.Result.ProcessName : null,
                    StartTime = (processResult.Success && processResult.Result != null) ? processResult.Result.StartTime : DateTime.MinValue,
                    EndTime = (processResult.Success && processResult.Result != null) ? processResult.Result.EndTime : null,
                    StartUserName = processResult.Result.StartUserName,
                    TaskList = taskList,
                    ProcessDefinition = (processResult.Success && processResult.Result != null) ? processResult.Result.ProcessDefinition : null,
                }
            };
        }

        /// <summary>
        /// 插入代办评论
        /// </summary>
        /// <param name="operatorUserName"></param>
        /// <param name="taskId"></param>
        /// <param name="comment"></param>
        /// <returns></returns>
        public static AjaxResponse<bool> InsertTaskComment(string operatorUserName, string taskId, string comment)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/runtime/tasks/" + taskId + "/comments")
               .AddHeader("Authorization", operatorUserName == AdminUserName ? GetAdminToken : GetToken(operatorUserName))
               .AddJsonBody(new
               {
                   message = comment,
                   saveProcessInstanceId = true
               })
               .Execute()
               .ThrowIfError()
               .AjaxResponse();

            return new AjaxResponse<bool>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Success
            };
        }

        /// <summary>
        /// 查询代办评论
        /// </summary>
        /// <param name="processId"></param>
        public static AjaxResponse<List<QueryTaskCommentOutput>> QueryTaskComment(string processId)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/history/historic-process-instances/" + processId + "/comments", Method.GET)
                  .AddHeader("Authorization", GetAdminToken)
                  .Execute()
                  .ThrowIfError()
                  .AjaxResponse<List<FlowableQueryTaskCommentOutput>>();

            var commentList = new List<QueryTaskCommentOutput>();
            if (result.Success && result.Result != null && result.Result.Count > 0)
            {
                result.Result = result.Result.OrderBy(x => x.time).ToList();
                commentList.AddRange(result.Result.Select(x => new QueryTaskCommentOutput
                {
                    TaskId = x.taskId,
                    Comment = x.message,
                    Time = x.time
                }));
            }

            return new AjaxResponse<List<QueryTaskCommentOutput>>
            {
                Success = result.Success,
                Error = result.Error,
                Result = commentList
            };
        }

        /// <summary>
        /// 查询历史代办
        /// </summary>
        /// <param name="processId"></param>
        /// <returns></returns>
        public static AjaxResponse<List<QueryHistoricTaskOutput>> QueryHistoricTask(string processId)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/history/historic-task-instances?processInstanceId=" + processId, Method.GET)
               .AddHeader("Authorization", GetAdminToken)
               .Execute()
               .ThrowIfError()
               .AjaxResponse<FlowableQueryHistoricTaskOutput>();

            if (result.Success && result.Result != null && result.Result.data != null && result.Result.data.Count > 0)
            {
                //清理未处理，但是已经存的代办，比如多人审批节点，一人审批即结束，其他人代办自动完结。
                //"MI_END" 多人审批 一人通过 其他代办变为冗余垃圾已办数据
                //"Change parent activity to End" 终止流程 代办变为冗余垃圾已办数据
                //暂时没想到其他好办法
                var removeList = result.Result.data.Where(x => x.deleteReason == "MI_END" || x.deleteReason == "Change parent activity to End").ToList();
                removeList.ForEach(x => { result.Result.data.Remove(x); });

                //按代办开始时间排序
                result.Result.data = result.Result.data.OrderBy(x => x.startTime).ToList();

                //获取代办评论
                var taskCommentList = QueryTaskComment(processId);

                if (taskCommentList.Success && taskCommentList.Result != null && taskCommentList.Result.Count > 0)
                {
                    foreach (var taskData in result.Result.data)
                    {
                        var commentList = taskCommentList.Result.Where(x => x.TaskId == taskData.id).ToList();
                        taskData.CommentList = commentList;
                    }
                }
            }

            var temp = result.Result?.data?.Select(x => x.assignee).ToList();

            return new AjaxResponse<List<QueryHistoricTaskOutput>>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.data == null) ? null : result.Result.data.Select(x => new QueryHistoricTaskOutput
                {
                    TaskId = x.id,
                    UserName = x.assignee,
                    Name = x.name,
                    Key = x.taskDefinitionKey,
                    StartTime = x.startTime,
                    EndTime = x.endTime,
                    CommentList = x.CommentList
                }).ToList()
            };
        }

        /// <summary>
        /// 查询已办(支持：用户名、流程Key、分页)
        /// </summary>
        /// <param name="query"></param>
        public static AjaxResponse<QueryFinishedTaskPagedOutput> QueryFinishedTasksPaged(QueryFinishedTaskPagedInput query)
        {
            //查询已办，用户名和流程Key没有值，必须置为null
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/query/historic-task-instances")
                .AddHeader("Authorization", GetAdminToken)
                .AddJsonBody(new FlowableQueryFinishedTaskPagedInput
                {
                    start = (query.PageIndex - 1) * query.PageSize,
                    size = query.PageSize,
                    taskAssignee = string.IsNullOrEmpty(query.UserName) ? null : query.UserName,
                    processDefinitionKey = string.IsNullOrEmpty(query.ProcessKey) ? null : query.ProcessKey
                })
                .Execute()
                .ThrowIfError()
                .AjaxResponse<FlowableQueryFinishedTaskOutput>();

            return new AjaxResponse<QueryFinishedTaskPagedOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.total == 0) ? null : new QueryFinishedTaskPagedOutput
                {
                    Total = result.Result.total,
                    Data = result.Result.data.Select(x => new QueryFinishedTaskOutput
                    {
                        TaskId = x.id,
                        UserName = x.assignee,
                        ProcessId = x.processInstanceId,
                        Name = x.name,
                        Key = x.taskDefinitionKey,
                        StartTime = x.startTime,
                        EndTime = x.endTime
                    }).ToList()
                }
            };
        }

        /// <summary>
        /// 批量审批
        /// </summary>
        /// <param name="approveList"></param>
        /// <returns></returns>
        public static AjaxResponse<List<AjaxResponse<ApproveOutput>>> BatchApprove(List<ApproveInput> approveList)
        {
            List<AjaxResponse<ApproveOutput>> resultList = new List<AjaxResponse<ApproveOutput>>();
            foreach (var item in approveList)
            {
                try
                {
                    var approveResult = Approve(item);
                    resultList.Add(approveResult);
                }
                catch (Exception ex)
                {
                    resultList.Add(new AjaxResponse<ApproveOutput>
                    {
                        Success = false,
                        Error = new ErrorInfo
                        {
                            Code = "500",
                            Message = ex.Message,
                            Details = ex.StackTrace
                        }
                    });
                }
            }

            return new AjaxResponse<List<AjaxResponse<ApproveOutput>>>
            {
                Success = true,
                Result = resultList
            };
        }

        /// <summary>
        /// 批量终止流程
        /// </summary>
        /// <param name="operatorUserName"></param>
        /// <param name="processIds"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public static AjaxResponse<List<AjaxResponse<QueryProcessOutput>>> BatchAbortProcess(string operatorUserName, string[] processIds, string reason)
        {
            var result = new List<AjaxResponse<QueryProcessOutput>>();

            foreach (var item in processIds)
            {
                try
                {
                    var abortResult = AbortProcess(operatorUserName, item, reason);
                    result.Add(new AjaxResponse<QueryProcessOutput>
                    {
                        Success = abortResult.Success,
                        Error = abortResult.Error,
                        Result = abortResult.Result
                    });
                }
                catch (Exception ex)
                {
                    result.Add(new AjaxResponse<QueryProcessOutput>
                    {
                        Success = false,
                        Error = new ErrorInfo
                        {
                            Code = "500",
                            Message = ex.Message,
                            Details = ex.StackTrace
                        },
                        Result = new QueryProcessOutput { ProcessId = item }
                    });
                }
            }

            return new AjaxResponse<List<AjaxResponse<QueryProcessOutput>>>
            {
                Success = true,
                Result = result
            };
        }

        /// <summary>
        /// 查询流程定义
        /// </summary>
        /// <param name="processDefinitionId"></param>
        /// <returns></returns>
        public static AjaxResponse<QueryProcessDefinitionOutput> QueryProcessDefinition(string processDefinitionId)
        {
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/repository/process-definitions/" + HttpUtility.UrlEncode(processDefinitionId) + "/model", Method.GET)
               .AddHeader("Authorization", GetAdminToken)
               .Execute()
               .ThrowIfError()
               .AjaxResponse<FlowableQueryProcessDefinitionOutput>();

            return new AjaxResponse<QueryProcessDefinitionOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = (result.Result == null || result.Result.processes == null) ? null : new QueryProcessDefinitionOutput
                {
                    ProcessKey = result.Result.processes[0].id,
                    ProcessName = result.Result.processes[0].name,
                    DataObjectList = result.Result.processes[0].dataObjects.Select(x => new QueryProcessDefinitionDataObject
                    {
                        Id = x.id,
                        Name = x.name,
                        Value = x.value,
                        Type = x.type
                    }).ToList(),
                    FlowElementList = result.Result.processes[0].flowElementMap.Where(x => x.Value.incomingFlows != null || x.Value.outgoingFlows != null).Select(x => new QueryProcessDefinitionFlowElement
                    {
                        Key = x.Value.id,
                        Name = x.Value.name,
                        Assignee = x.Value.assignee,
                        AttributeList = (x.Value.attributes == null || x.Value.attributes.Count == 0) ? null : x.Value.attributes.Select(y => new QueryProcessDefinitionAttribute
                        {
                            Name = y.Value[0].name,
                            Value = y.Value[0].value
                        }).ToList(),
                        IncomingFlowList = (x.Value.incomingFlows == null || x.Value.incomingFlows.Count == 0) ? null : x.Value.incomingFlows.Select(y => new QueryProcessDefinitionInOutFlow
                        {
                            Key = y.id,
                            Name = y.name,
                            ConditionExpression = y.conditionExpression,
                            SourceKey = y.sourceRef,
                            TargetKey = y.targetRef
                        }).ToList(),
                        OutgoingFlowList = (x.Value.outgoingFlows == null || x.Value.outgoingFlows.Count == 0) ? null : x.Value.outgoingFlows.Select(y => new QueryProcessDefinitionInOutFlow
                        {
                            Key = y.id,
                            Name = y.name,
                            ConditionExpression = y.conditionExpression,
                            SourceKey = y.sourceRef,
                            TargetKey = y.targetRef
                        }).ToList(),
                        LoopCharacteristic = x.Value.loopCharacteristics == null ? null : new QueryProcessDefinitionLoopCharacteristic
                        {
                            ListVariable = x.Value.loopCharacteristics.inputDataItem,
                            ElementVariable = x.Value.loopCharacteristics.elementVariable,
                            CompletionCondition = x.Value.loopCharacteristics.completionCondition,
                            IsSequential = x.Value.loopCharacteristics.sequential
                        }
                    }).ToList()
                }
            };
        }

        /// <summary>
        /// 查询最新的流程定义
        /// </summary>
        /// <param name="processKey"></param>
        /// <returns></returns>
        public static AjaxResponse<QueryProcessDefinitionOutput> QueryLatestProcessDefinition(string processKey)
        {
            //查询流程定义列表（最近更新的）
            var processDefinitionResult = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/repository/process-definitions?key=" + processKey + "&latest=true", Method.GET)
               .AddHeader("Authorization", GetAdminToken)
               .Execute()
               .ThrowIfError()
               .AjaxResponse<FlowableQueryProcessDefinitionListOutput>();

            if (processDefinitionResult.Result != null && processDefinitionResult.Result.data != null && processDefinitionResult.Result.data.Count > 0)
            {
                return QueryProcessDefinition(processDefinitionResult.Result.data.First().id);
            }

            return new AjaxResponse<QueryProcessDefinitionOutput> { Success = true };
        }

        /// <summary>
        /// 查询用户
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static AjaxResponse<QueryUserOutput> QueryUser(string userName)
        {
            //用户名统一小写
            userName = userName.ToLower();

            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/identity/users/" + userName, Method.GET)
               .AddHeader("Authorization", GetAdminToken)
               .Execute()
               .ThrowIfError()
               .AjaxResponse<FlowableQueryUserOutput>();

            return new AjaxResponse<QueryUserOutput>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Result == null ? null : new QueryUserOutput
                {
                    UserName = result.Result.id,
                    Email = result.Result.email
                }
            };
        }

        /// <summary>
        /// 创建用户
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static AjaxResponse<bool> CreateUser(string userName)
        {
            //用户名统一小写
            userName = userName.ToLower();

            //创建用户
            var result = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/identity/users")
               .AddHeader("Authorization", GetAdminToken)
               .AddJsonBody(new
               {
                   id = userName,
                   lastName = userName,
                   email = userName + DefaultEmailSuffix,
                   password = DefaultUserPassword
               })
               .Execute()
               .ThrowIfError()
               .AjaxResponse<FlowableQueryUserOutput>();

            return new AjaxResponse<bool>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Success
            };

            ////加入用户组
            //var addGroupResult = HttpClient.BeginRequest(BaseUrl, "/flowable-rest/service/identity/groups/Users/members")
            //    .AddHeader("Authorization", GetAdminToken)
            //    .AddJsonBody(new
            //    {
            //        userId = userName
            //    })
            //    .Execute()
            //    .ThrowIfError()
            //    .AjaxResponse();

            //return new AjaxResponse<bool>
            //{
            //    Success = result.Success && addGroupResult.Success,
            //    Error = !result.Success ? result.Error : addGroupResult.Error,
            //    Result = result.Success && addGroupResult.Success
            //};
        }

        /// <summary>
        /// 校验用户是否存在
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static AjaxResponse<bool> CheckUserExist(string userName)
        {
            var result = QueryUser(userName);

            //授权系统自动创建用户
            if (!result.Success && Convert.ToBoolean(IsAutoCreateUser))
            {
                var createUserResult = CreateUser(userName);
                return createUserResult;
            }

            return new AjaxResponse<bool>
            {
                Success = result.Success,
                Error = result.Error,
                Result = result.Success
            };
        }
    }
}
