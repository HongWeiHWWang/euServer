﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class StartProcessOutput
    {
        /// <summary>
        /// 流程实例Id
        /// </summary>
        public string ProcessId { get; set; }

        /// <summary>
        /// 流程定义Id
        /// </summary>
        public string ProcessDefinitionId { get; set; }

        /// <summary>
        /// 代办列表
        /// </summary>
        public List<QueryTaskOutput> TaskList { get; set; }

        /// <summary>
        /// 流程定义
        /// </summary>
        public QueryProcessDefinitionOutput ProcessDefinition { get; set; }
    }

    internal class FlowableStartProcessOutput
    {
        /// <summary>
        /// 流程实例Id
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// 流程定义Id
        /// </summary>
        public string processDefinitionId { get; set; }
    }
}
