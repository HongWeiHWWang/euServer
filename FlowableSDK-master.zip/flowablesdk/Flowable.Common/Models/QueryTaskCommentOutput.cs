﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryTaskCommentOutput
    {
        /// <summary>
        /// 代办Id
        /// </summary>
        public string TaskId { get; set; }

        /// <summary>
        /// 评论
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        /// 时间
        /// </summary>
        public DateTime Time { get; set; }
    }

    internal class FlowableQueryTaskCommentOutput
    {
        /// <summary>
        /// 代办Id
        /// </summary>
        public string taskId { get; set; }

        /// <summary>
        /// 评论
        /// </summary>
        public string message { get; set; }

        /// <summary>
        /// 时间
        /// </summary>
        public DateTime time { get; set; }
    }
}
