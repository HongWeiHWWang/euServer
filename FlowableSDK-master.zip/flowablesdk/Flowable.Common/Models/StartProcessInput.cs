﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class StartProcessInput
    {
        /// <summary>
        /// 操作人
        /// </summary>
        public string Operator { get; set; }

        /// <summary>
        /// 流程Key
        /// </summary>
        public string ProcessKey { get; set; }

        /// <summary>
        /// 业务Id
        /// </summary>
        public string BusinessId { get; set; }

        /// <summary>
        /// 动态变量集合
        /// </summary>
        public IList<ProcessVariable> Variables { get; set; }

        /// <summary>
        /// 是否返回代办（默认是）
        /// </summary>
        public bool IsReturnTask { get; set; } = true;
    }

    internal class FlowableStartProcessInput
    {
        /// <summary>
        /// 流程Key
        /// </summary>
        public string processDefinitionKey { get; set; }

        /// <summary>
        /// 业务标识
        /// </summary>
        public string businessKey { get; set; }

        /// <summary>
        /// 动态变量集合
        /// </summary>
        public IList<FlowableProcessVariable> variables { get; set; }
    }
}
