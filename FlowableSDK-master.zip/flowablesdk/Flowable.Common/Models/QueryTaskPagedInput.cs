﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryTaskPagedInput
    {
        /// <summary>
        /// 页码(默认1)
        /// </summary>
        public int PageIndex { get; set; } = 1;

        /// <summary>
        /// 每页数量(默认10)
        /// </summary>
        public int PageSize { get; set; } = 10;

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 流程Key
        /// </summary>
        public string ProcessKey { get; set; }
    }

    internal class FlowableQueryTaskPagedInput
    {
        /// <summary>
        /// 起始数
        /// </summary>
        public int start { get; set; }

        /// <summary>
        /// 每页数量
        /// </summary>
        public int size { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string assignee { get; set; }

        /// <summary>
        /// 流程Key
        /// </summary>
        public string processDefinitionKey { get; set; }
    }
}
