﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryProcessDefinitionOutput
    {
        /// <summary>
        /// 流程Key
        /// </summary>
        public string ProcessKey { get; set; }

        /// <summary>
        /// 流程名
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// 数据对象列表
        /// </summary>
        public List<QueryProcessDefinitionDataObject> DataObjectList { get; set; }

        /// <summary>
        /// 流程节点列表
        /// </summary>
        public List<QueryProcessDefinitionFlowElement> FlowElementList { get; set; }
    }

    public class QueryProcessDefinitionDataObject
    {
        /// <summary>
        /// 数据对象Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 数据对象名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 数据对象值
        /// </summary>
        public object Value { get; set; }

        /// <summary>
        /// 数据对象类型（string、boolean、datetime、double、int、long）
        /// </summary>
        public string Type { get; set; }
    }

    public class QueryProcessDefinitionFlowElement
    {
        /// <summary>
        /// 节点Key
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// 节点名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 分配人
        /// </summary>
        public string Assignee { get; set; }

        /// <summary>
        /// 属性列表（自定义）
        /// </summary>
        public List<QueryProcessDefinitionAttribute> AttributeList { get; set; }

        /// <summary>
        /// 传入流程列表
        /// </summary>
        public List<QueryProcessDefinitionInOutFlow> IncomingFlowList { get; set; }

        /// <summary>
        /// 传出流程列表
        /// </summary>
        public List<QueryProcessDefinitionInOutFlow> OutgoingFlowList { get; set; }

        /// <summary>
        /// 循环特性
        /// </summary>
        public QueryProcessDefinitionLoopCharacteristic LoopCharacteristic { get; set; }
    }

    public class QueryProcessDefinitionLoopCharacteristic
    {
        /// <summary>
        /// 集合变量
        /// </summary>
        public string ListVariable { get; set; }

        /// <summary>
        /// 完成条件
        /// </summary>
        public string CompletionCondition { get; set; }

        /// <summary>
        /// 元素变量
        /// </summary>
        public string ElementVariable { get; set; }

        /// <summary>
        /// 是否顺序
        /// </summary>
        public bool IsSequential { get; set; }
    }

    public class QueryProcessDefinitionAttribute
    {
        /// <summary>
        /// 属性名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 属性值
        /// </summary>
        public string Value { get; set; }
    }

    public class QueryProcessDefinitionInOutFlow
    {
        /// <summary>
        /// 流程线Key
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// 流程线名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 条件表达式
        /// </summary>
        public string ConditionExpression { get; set; }

        /// <summary>
        /// 来源Key
        /// </summary>
        public string SourceKey { get; set; }

        /// <summary>
        /// 目标Key
        /// </summary>
        public string TargetKey { get; set; }
    }

    internal class FlowableQueryProcessDefinitionOutput
    {
        public List<FlowableQueryProcessDefinitionProcess> processes { get; set; }
    }

    internal class FlowableQueryProcessDefinitionProcess
    {
        public string id { get; set; }

        public string name { get; set; }

        public List<FlowableQueryProcessDefinitionDataObject> dataObjects { get; set; }

        public Dictionary<string, FlowableQueryProcessDefinitionFlowElement> flowElementMap { get; set; }
    }

    internal class FlowableQueryProcessDefinitionDataObject
    {
        public string id { get; set; }

        public string name { get; set; }

        public object value { get; set; }

        public string type { get; set; }
    }

    internal class FlowableQueryProcessDefinitionFlowElement
    {
        public string id { get; set; }

        public string name { get; set; }

        public string assignee { get; set; }

        public Dictionary<string,List<FlowableQueryProcessDefinitionAttribute>> attributes { get; set; }

        public List<FlowableQueryProcessDefinitionInOutFlow> incomingFlows { get; set; }

        public List<FlowableQueryProcessDefinitionInOutFlow> outgoingFlows { get; set; }

        public FlowableQueryProcessDefinitionLoopCharacteristic loopCharacteristics { get; set; }
    }

    internal class FlowableQueryProcessDefinitionLoopCharacteristic
    {
        public string inputDataItem { get; set; }

        public string completionCondition { get; set; }

        public string elementVariable { get; set; }

        public bool sequential { get; set; }
    }

    internal class FlowableQueryProcessDefinitionAttribute
    {
        public string name { get; set; }

        public string value { get; set; }
    }

    internal class FlowableQueryProcessDefinitionInOutFlow
    {
        public string id { get; set; }

        public string name { get; set; }

        public string conditionExpression { get; set; }

        public string sourceRef { get; set; }

        public string targetRef { get; set; }
    }

    internal class FlowableQueryProcessDefinitionListOutput
    {
        public List<FlowableQueryProcessDefinitionBaseInfoOutput> data { get; set; }

        public int total { get; set; }

    }

    internal class FlowableQueryProcessDefinitionBaseInfoOutput
    {
        public string id { get; set; }

        public string key { get; set; }

        public int version { get; set; }

        public string name { get; set; }
    }
}
