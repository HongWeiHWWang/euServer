﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryHistoricTaskOutput
    {
        /// <summary>
        /// 代办Id
        /// </summary>
        public string TaskId { get; set; }

        /// <summary>
        /// 流程节点名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 流程节点Key
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// 代办人
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 代办开始时间
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// 代办结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// 评论
        /// </summary>
        public List<QueryTaskCommentOutput> CommentList { get; set; }
    }

    internal class FlowableQueryHistoricTaskOutput
    {
        public List<FlowableQueryHistoricTaskDataOutput> data { get; set; }
        public int total { get; set; }
    }

    internal class FlowableQueryHistoricTaskDataOutput
    {
        /// <summary>
        /// 代办Id
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// 流程节点名
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// 流程节点Key
        /// </summary>
        public string taskDefinitionKey { get; set; }

        /// <summary>
        /// 代办人
        /// </summary>
        public string assignee { get; set; }

        /// <summary>
        /// 代办开始时间
        /// </summary>
        public DateTime startTime { get; set; }

        /// <summary>
        /// 代办结束时间
        /// </summary>
        public DateTime? endTime { get; set; }

        /// <summary>
        /// 评论
        /// </summary>
        public List<QueryTaskCommentOutput> CommentList { get; set; }

        /// <summary>
        /// 代办删除原因
        /// </summary>
        public string deleteReason { get; set; }
    }
}
