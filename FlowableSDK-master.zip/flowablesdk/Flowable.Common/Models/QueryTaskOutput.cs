﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryTaskOutput
    {
        /// <summary>
        /// 代办Id
        /// </summary>
        public string TaskId { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 流程Id
        /// </summary>
        public string ProcessId { get; set; }

        /// <summary>
        /// 流程节点名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 流程节点Key
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// 流程定义Id
        /// </summary>
        public string ProcessDefinitionId { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateTime { get; set; }
    }

    internal class FlowableQueryTaskOutput
    {
        /// <summary>
        /// 代办数据集合
        /// </summary>
        public List<FlowableQueryTaskDataOutput> data { get; set; }

        /// <summary>
        /// 代办数量
        /// </summary>
        public int total { get; set; }
    }

    internal class FlowableQueryTaskDataOutput
    {
        /// <summary>
        /// 代办Id
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// 代办人（用户名）
        /// </summary>
        public string assignee { get; set; }

        /// <summary>
        /// 流程Id
        /// </summary>
        public string processInstanceId { get; set; }

        /// <summary>
        /// 流程节点名
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// 流程节点Key
        /// </summary>
        public string taskDefinitionKey { get; set; }

        /// <summary>
        /// 流程定义Id
        /// </summary>
        public string processDefinitionId { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime createTime { get; set; }
    }
}


