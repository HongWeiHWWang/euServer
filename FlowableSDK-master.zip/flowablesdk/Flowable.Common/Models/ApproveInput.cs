﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class ApproveInput
    {
        /// <summary>
        /// 操作人
        /// </summary>
        public string Operator { get; set; }

        /// <summary>
        /// 代办Id
        /// </summary>
        public string TaskId { get; set; }

        /// <summary>
        /// 流程Id
        /// </summary>
        public string ProcessId { get; set; }

        /// <summary>
        /// 理由
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// 动态变量集合
        /// </summary>
        public IList<ProcessVariable> Variables { get; set; }

        /// <summary>
        /// 是否返回代办（默认是）
        /// </summary>
        public bool IsReturnTask { get; set; } = true;
    }
}
