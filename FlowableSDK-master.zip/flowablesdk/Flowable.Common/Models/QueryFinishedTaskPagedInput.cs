﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryFinishedTaskPagedInput
    {
        /// <summary>
        /// 页码(默认1)
        /// </summary>
        public int PageIndex { get; set; } = 1;

        /// <summary>
        /// 每页数量(默认10)
        /// </summary>
        public int PageSize { get; set; } = 10;

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 流程Key
        /// </summary>
        public string ProcessKey { get; set; }
    }

    internal class FlowableQueryFinishedTaskPagedInput
    {
        /// <summary>
        /// 起始数
        /// </summary>
        public int start { get; set; }

        /// <summary>
        /// 每页数量
        /// </summary>
        public int size { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string taskAssignee { get; set; }

        /// <summary>
        /// 流程Key
        /// </summary>
        public string processDefinitionKey { get; set; }

        /// <summary>
        /// 是否完成的代办（只读默认值是true）
        /// </summary>
        public bool finished { get { return true; } }

        /// <summary>
        /// 流程变量（只读默认值是审批通过变量）
        /// </summary>
        public List<Dictionary<string, object>> processVariables
        {
            get
            {
                var dict = new Dictionary<string, object>();
                dict.Add("name", "approved");
                dict.Add("value", true);
                dict.Add("operation", "equals");
                return new List<Dictionary<string, object>> { dict };
            }
        }
    }
}
