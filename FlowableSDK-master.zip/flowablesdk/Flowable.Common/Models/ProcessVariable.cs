﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class ProcessVariable
    {
        /// <summary>
        /// 变量名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 变量值(字符串、数字、数组等)
        /// </summary>
        public object Value { get; set; }
    }

    internal class FlowableProcessVariable
    {
        /// <summary>
        /// 变量名
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// 变量值(字符串、数字、数组等)
        /// </summary>
        public object value { get; set; }
    }
}
