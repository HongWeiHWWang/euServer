﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class ApproveOutput
    {
        /// <summary>
        /// 流程实例Id
        /// </summary>
        public string ProcessId { get; set; }

        /// <summary>
        /// 业务Id
        /// </summary>
        public string BusinessId { get; set; }

        /// <summary>
        /// 流程名称
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// 流程创建人
        /// </summary>
        public string StartUserName { get; set; }

        /// <summary>
        /// 代办列表
        /// </summary>
        public List<QueryTaskOutput> TaskList { get; set; }

        /// <summary>
        /// 流程定义
        /// </summary>
        public QueryProcessDefinitionOutput ProcessDefinition { get; set; }
    }
}
