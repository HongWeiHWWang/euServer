﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowable.Common.Models
{
    public class QueryTaskPagedOutput
    {
        public int Total { get; set; }

        public List<QueryTaskOutput> Data { get; set; }
    }
}
