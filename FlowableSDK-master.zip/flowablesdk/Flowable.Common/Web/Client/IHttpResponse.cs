﻿using Flowable.Common.Web.Models;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
namespace Flowable.Common.Web.Client
{
    public interface IHttpResponse
    {
        string ErrorMessage { get; }

        string Server { get; }

        Uri ResponseUri { get; }

        Exception ErrorException { get; }

        HttpStatusCode StatusCode { get; }

        string ContentEncoding { get; }

        long ContentLength { get; }

        string ContentType { get; }

        string StatusDescription { get; }

        Version ProtocolVersion { get; }

        string Content { get; }

        byte[] RawBytes { get; }

        IList<Parameter> Headers { get; }

        AjaxResponse<TData> AjaxResponse<TData>();

        AjaxResponse AjaxResponse();

        IHttpResponse ThrowIfError();
    }
}
