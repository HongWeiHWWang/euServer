﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.IO;
using Flowable.Common.Web.Models;
using Newtonsoft.Json;

namespace Flowable.Common.Web.Client
{
    public class HttpClient : IHttpResponse
    {
        private static HttpStatusCode[] AjaxResponseStatusCodes = new HttpStatusCode[]
        {
            HttpStatusCode.OK,
            HttpStatusCode.Created,
            HttpStatusCode.NoContent,
            HttpStatusCode.BadRequest,
            HttpStatusCode.Unauthorized,
            HttpStatusCode.Forbidden,
            HttpStatusCode.NotFound,
            HttpStatusCode.InternalServerError
        };

        private RestClient client;
        private IRestResponse response;

        private HttpClient(string baseUrl, string path, Method method = Method.POST)
        {
            this.BaseUrl = baseUrl;
            this.client = new RestClient(baseUrl);
            this.client.Encoding = Encoding.UTF8;

            if (String.IsNullOrWhiteSpace(path))
            {
                this.Reqeust = new RestRequest(ConvertToRestSharpMethod(method));
            }
            else
            {
                this.Reqeust = new RestRequest(path, ConvertToRestSharpMethod(method));
            }
        }

        public string BaseUrl { get; private set; }

        internal IRestRequest Reqeust { get; }

        public static HttpClient BeginRequest(string baseUrl, Method method = Method.POST)
        {
            return new HttpClient(baseUrl, "", method);
        }

        public static HttpClient BeginRequest(string baseUrl, string path, Method method = Method.POST)
        {
            return new HttpClient(baseUrl, path, method);
        }

        public HttpClient AddJsonBody(object jsonBody)
        {
            this.Reqeust.AddJsonBody(jsonBody);
            return this;
        }

        public HttpClient AddBody(object body)
        {
            this.Reqeust.AddBody(body);
            return this;
        }

        public HttpClient AddParameter(string name, object value)
        {
            this.Reqeust.AddParameter(name, value);
            return this;
        }

        public HttpClient AddHeader(string name, string value)
        {
            this.Reqeust.AddHeader(name, value);
            return this;
        }

        public HttpClient AddFile(string name, string path, string contentType = null)
        {
            this.Reqeust.AddFile(name, path, contentType);
            return this;
        }

        public HttpClient AddFile(string name, byte[] bytes, string fileName, string contentType = null)
        {
            this.Reqeust.AddFile(name, bytes, fileName, contentType);
            return this;
        }

        public HttpClient AddFile(string name, Action<Stream> writer, string fileName, long contentLength, string contentType = null)
        {
            this.Reqeust.AddFile(name, writer, fileName, contentLength, contentType);
            return this;
        }

        public HttpClient AddFileBytes(string name, byte[] bytes, string filename, string contentType = "application/x-gzip")
        {
            this.Reqeust.AddFileBytes(name, bytes, filename, contentType);
            return this;
        }

        public IHttpResponse Execute()
        {
            this.response = client.Execute(Reqeust);
            return this;
        }

        private IRestResponse GetResponse()
        {
            return this.response;
        }

        AjaxResponse<TResult> IHttpResponse.AjaxResponse<TResult>()
        {
            var content = response.Content;

            switch (response.StatusCode)
            {
                case HttpStatusCode.OK:
                case HttpStatusCode.Created:
                    {
                        var obj = JsonConvert.DeserializeObject<TResult>(content);
                        return new AjaxResponse<TResult>
                        {
                            Success = true,
                            Result = obj
                        };
                    }
                case HttpStatusCode.Unauthorized:
                    {
                        return new AjaxResponse<TResult>
                        {
                            Success = false,
                            Error = new ErrorInfo
                            {
                                Code = "401",
                                Message = "Unauthorized"
                            }
                        };
                    }
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.NotFound:
                case HttpStatusCode.InternalServerError:
                    {
                        var error = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);
                        return new AjaxResponse<TResult>
                        {
                            Success = false,
                            Error = new ErrorInfo
                            {
                                Code = ((int)response.StatusCode).ToString(),
                                Message = error.ContainsKey("message") ? error["message"] : null,
                                Details = error.ContainsKey("exception") ? error["exception"] : null
                            }
                        };
                    }
                default:
                    {
                        return new AjaxResponse<TResult>
                        {
                            Success = false,
                            Error = new ErrorInfo
                            {
                                Code = response.StatusCode.ToString(),
                                Message = content
                            }
                        };
                    }
            }
        }

        AjaxResponse IHttpResponse.AjaxResponse()
        {
            var content = response.Content;

            switch (response.StatusCode)
            {
                case HttpStatusCode.OK:
                case HttpStatusCode.Created:
                    {
                        return new AjaxResponse
                        {
                            Success = true,
                            Result = content
                        };
                    }
                case HttpStatusCode.Unauthorized:
                    {
                        return new AjaxResponse
                        {
                            Success = false,
                            Error = new ErrorInfo
                            {
                                Code = "401",
                                Message = "Unauthorized"
                            }
                        };
                    }
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.NotFound:
                case HttpStatusCode.InternalServerError:
                    {
                        var error = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);
                        return new AjaxResponse
                        {
                            Success = false,
                            Error = new ErrorInfo
                            {
                                Code = ((int)response.StatusCode).ToString(),
                                Message = error["message"],
                                Details = error["exception"]
                            }
                        };
                    }
                default:
                    {
                        return new AjaxResponse
                        {
                            Success = false,
                            Error = new ErrorInfo
                            {
                                Code = response.StatusCode.ToString(),
                                Message = content
                            }
                        };
                    }
            }
        }

        IHttpResponse IHttpResponse.ThrowIfError()
        {
            if (!AjaxResponseStatusCodes.Contains(this.response.StatusCode))
            {
                throw new Exception(this.response.ErrorMessage, this.response.ErrorException);
            }

            return this;
        }

        string IHttpResponse.ErrorMessage => this.GetResponse().ErrorMessage;

        string IHttpResponse.Server => this.GetResponse().Server;

        Uri IHttpResponse.ResponseUri => this.GetResponse().ResponseUri;

        Exception IHttpResponse.ErrorException => this.GetResponse().ErrorException;

        HttpStatusCode IHttpResponse.StatusCode => this.GetResponse().StatusCode;

        string IHttpResponse.ContentEncoding => this.GetResponse().ContentEncoding;

        long IHttpResponse.ContentLength => this.GetResponse().ContentLength;

        string IHttpResponse.ContentType => this.GetResponse().ContentType;

        string IHttpResponse.StatusDescription => this.GetResponse().StatusDescription;

        Version IHttpResponse.ProtocolVersion => this.GetResponse().ProtocolVersion;

        string IHttpResponse.Content => this.GetResponse().Content;

        byte[] IHttpResponse.RawBytes => this.GetResponse().RawBytes;

        IList<Parameter> IHttpResponse.Headers => this.GetResponse().Headers;

        private RestSharp.Method ConvertToRestSharpMethod(Method method)
        {
            switch (method)
            {
                case Method.GET:
                    return RestSharp.Method.GET;
                case Method.POST:
                    return RestSharp.Method.POST;
                case Method.PUT:
                    return RestSharp.Method.PUT;
                case Method.DELETE:
                    return RestSharp.Method.DELETE;
                case Method.HEAD:
                    return RestSharp.Method.HEAD;
                case Method.OPTIONS:
                    return RestSharp.Method.OPTIONS;
                case Method.PATCH:
                    return RestSharp.Method.PATCH;
                case Method.MERGE:
                    return RestSharp.Method.MERGE;
                case Method.COPY:
                    return RestSharp.Method.COPY;
                default:
                    return RestSharp.Method.GET;
            }
        }

        private bool IsJsonFormat(string content)
        {
            if (String.IsNullOrWhiteSpace(content))
                return false;
            content = content.Trim();
            return content.StartsWith("{") && content.EndsWith("}");
        }
    }
}
