﻿namespace Flowable.Demo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.StartProcess = new System.Windows.Forms.Button();
            this.QueryUserNameTask = new System.Windows.Forms.Button();
            this.ApproveTrue = new System.Windows.Forms.Button();
            this.AbortProcess = new System.Windows.Forms.Button();
            this.ProcessKey = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.StartProcessVariables = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.QueryProcessKeyTask = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.QueryFinishedTask = new System.Windows.Forms.Button();
            this.QueryTaskPaged = new System.Windows.Forms.Button();
            this.PageSize = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.PageIndex = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ProcessIdApprove = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.TaskId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Test = new System.Windows.Forms.Button();
            this.BatchAbortProcess = new System.Windows.Forms.Button();
            this.BatchApprove = new System.Windows.Forms.Button();
            this.DeploymentProcess = new System.Windows.Forms.Button();
            this.ClearData = new System.Windows.Forms.Button();
            this.EngineInfo = new System.Windows.Forms.Button();
            this.DataResult = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PMApprove = new System.Windows.Forms.Button();
            this.DemoFunctionApprove = new System.Windows.Forms.Button();
            this.DemoLeaderApprove = new System.Windows.Forms.Button();
            this.DemoEnd = new System.Windows.Forms.Button();
            this.DemoStart = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ProcessId = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.QueryProcessIdTask = new System.Windows.Forms.Button();
            this.GetProcess = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // StartProcess
            // 
            this.StartProcess.Location = new System.Drawing.Point(15, 49);
            this.StartProcess.Name = "StartProcess";
            this.StartProcess.Size = new System.Drawing.Size(90, 23);
            this.StartProcess.TabIndex = 1;
            this.StartProcess.Text = "启动流程实例";
            this.StartProcess.UseVisualStyleBackColor = true;
            this.StartProcess.Click += new System.EventHandler(this.StartProcess_Click);
            // 
            // QueryUserNameTask
            // 
            this.QueryUserNameTask.Location = new System.Drawing.Point(11, 46);
            this.QueryUserNameTask.Name = "QueryUserNameTask";
            this.QueryUserNameTask.Size = new System.Drawing.Size(93, 23);
            this.QueryUserNameTask.TabIndex = 1;
            this.QueryUserNameTask.Text = "查询用户代办";
            this.QueryUserNameTask.UseVisualStyleBackColor = true;
            this.QueryUserNameTask.Click += new System.EventHandler(this.QueryUserNameTask_Click);
            // 
            // ApproveTrue
            // 
            this.ApproveTrue.Location = new System.Drawing.Point(288, 18);
            this.ApproveTrue.Name = "ApproveTrue";
            this.ApproveTrue.Size = new System.Drawing.Size(64, 51);
            this.ApproveTrue.TabIndex = 2;
            this.ApproveTrue.Text = "审批同意\r\n(流转)";
            this.ApproveTrue.UseVisualStyleBackColor = true;
            this.ApproveTrue.Click += new System.EventHandler(this.ApproveTrue_Click);
            // 
            // AbortProcess
            // 
            this.AbortProcess.Location = new System.Drawing.Point(313, 19);
            this.AbortProcess.Name = "AbortProcess";
            this.AbortProcess.Size = new System.Drawing.Size(131, 23);
            this.AbortProcess.TabIndex = 3;
            this.AbortProcess.Text = "终止流程(审批否决)";
            this.AbortProcess.UseVisualStyleBackColor = true;
            this.AbortProcess.Click += new System.EventHandler(this.AbortProcess_Click);
            // 
            // ProcessKey
            // 
            this.ProcessKey.Location = new System.Drawing.Point(65, 20);
            this.ProcessKey.Name = "ProcessKey";
            this.ProcessKey.ReadOnly = true;
            this.ProcessKey.Size = new System.Drawing.Size(112, 21);
            this.ProcessKey.TabIndex = 4;
            this.ProcessKey.Text = "AdjustApplication";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "流程Key";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(182, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "变量集合";
            // 
            // StartProcessVariables
            // 
            this.StartProcessVariables.Location = new System.Drawing.Point(236, 20);
            this.StartProcessVariables.Multiline = true;
            this.StartProcessVariables.Name = "StartProcessVariables";
            this.StartProcessVariables.Size = new System.Drawing.Size(441, 52);
            this.StartProcessVariables.TabIndex = 7;
            this.StartProcessVariables.Text = "[{\"Name\": \"LeaderList\",\"Value\": [\"张三\",\"李四\"]},{\"Name\": \"PMList\",\"Value\": [\"王五\",\"赵六" +
    "\"]},{\"Name\": \"FunctionList\",\"Value\": [\"孙七\",\"周八\"]},{\"Name\": \"IsEnd\",\"Value\": true" +
    "}]";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.QueryProcessKeyTask);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.StartProcessVariables);
            this.groupBox1.Controls.Add(this.StartProcess);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ProcessKey);
            this.groupBox1.Location = new System.Drawing.Point(13, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(690, 84);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "启动流程";
            // 
            // QueryProcessKeyTask
            // 
            this.QueryProcessKeyTask.Location = new System.Drawing.Point(111, 49);
            this.QueryProcessKeyTask.Name = "QueryProcessKeyTask";
            this.QueryProcessKeyTask.Size = new System.Drawing.Size(111, 23);
            this.QueryProcessKeyTask.TabIndex = 13;
            this.QueryProcessKeyTask.Text = "查询流程Key代办";
            this.QueryProcessKeyTask.UseVisualStyleBackColor = true;
            this.QueryProcessKeyTask.Click += new System.EventHandler(this.QueryProcessKeyTask_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.QueryFinishedTask);
            this.groupBox2.Controls.Add(this.QueryTaskPaged);
            this.groupBox2.Controls.Add(this.PageSize);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.QueryUserNameTask);
            this.groupBox2.Controls.Add(this.PageIndex);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.UserName);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(13, 164);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(319, 79);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "查询代办、已办";
            // 
            // QueryFinishedTask
            // 
            this.QueryFinishedTask.Location = new System.Drawing.Point(214, 46);
            this.QueryFinishedTask.Name = "QueryFinishedTask";
            this.QueryFinishedTask.Size = new System.Drawing.Size(92, 23);
            this.QueryFinishedTask.TabIndex = 13;
            this.QueryFinishedTask.Text = "查询分页已办";
            this.QueryFinishedTask.UseVisualStyleBackColor = true;
            this.QueryFinishedTask.Click += new System.EventHandler(this.QueryFinishedTask_Click);
            // 
            // QueryTaskPaged
            // 
            this.QueryTaskPaged.Location = new System.Drawing.Point(112, 46);
            this.QueryTaskPaged.Name = "QueryTaskPaged";
            this.QueryTaskPaged.Size = new System.Drawing.Size(94, 23);
            this.QueryTaskPaged.TabIndex = 13;
            this.QueryTaskPaged.Text = "查询分页代办";
            this.QueryTaskPaged.UseVisualStyleBackColor = true;
            this.QueryTaskPaged.Click += new System.EventHandler(this.QueryTaskPaged_Click);
            // 
            // PageSize
            // 
            this.PageSize.Location = new System.Drawing.Point(276, 19);
            this.PageSize.Name = "PageSize";
            this.PageSize.Size = new System.Drawing.Size(28, 21);
            this.PageSize.TabIndex = 12;
            this.PageSize.Text = "10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(227, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "每页量";
            // 
            // PageIndex
            // 
            this.PageIndex.Location = new System.Drawing.Point(186, 19);
            this.PageIndex.Name = "PageIndex";
            this.PageIndex.Size = new System.Drawing.Size(30, 21);
            this.PageIndex.TabIndex = 10;
            this.PageIndex.Text = "1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(140, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 9;
            this.label11.Text = "分页码";
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(59, 19);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(69, 21);
            this.UserName.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "用户名";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ProcessIdApprove);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.TaskId);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.ApproveTrue);
            this.groupBox3.Location = new System.Drawing.Point(338, 164);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(365, 79);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "流程审批";
            // 
            // ProcessIdApprove
            // 
            this.ProcessIdApprove.Location = new System.Drawing.Point(52, 48);
            this.ProcessIdApprove.Name = "ProcessIdApprove";
            this.ProcessIdApprove.Size = new System.Drawing.Size(230, 21);
            this.ProcessIdApprove.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "流程Id";
            // 
            // TaskId
            // 
            this.TaskId.Location = new System.Drawing.Point(52, 20);
            this.TaskId.Name = "TaskId";
            this.TaskId.Size = new System.Drawing.Size(230, 21);
            this.TaskId.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "代办Id";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Test);
            this.groupBox4.Controls.Add(this.BatchAbortProcess);
            this.groupBox4.Controls.Add(this.BatchApprove);
            this.groupBox4.Controls.Add(this.DeploymentProcess);
            this.groupBox4.Controls.Add(this.ClearData);
            this.groupBox4.Controls.Add(this.EngineInfo);
            this.groupBox4.Controls.Add(this.DataResult);
            this.groupBox4.Location = new System.Drawing.Point(13, 306);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(690, 241);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "数据";
            // 
            // Test
            // 
            this.Test.Location = new System.Drawing.Point(602, 20);
            this.Test.Name = "Test";
            this.Test.Size = new System.Drawing.Size(75, 23);
            this.Test.TabIndex = 15;
            this.Test.Text = "自定义测试";
            this.Test.UseVisualStyleBackColor = true;
            this.Test.Click += new System.EventHandler(this.Test_Click);
            // 
            // BatchAbortProcess
            // 
            this.BatchAbortProcess.Location = new System.Drawing.Point(377, 20);
            this.BatchAbortProcess.Name = "BatchAbortProcess";
            this.BatchAbortProcess.Size = new System.Drawing.Size(93, 23);
            this.BatchAbortProcess.TabIndex = 14;
            this.BatchAbortProcess.Text = "批量终止流程";
            this.BatchAbortProcess.UseVisualStyleBackColor = true;
            this.BatchAbortProcess.Click += new System.EventHandler(this.BatchAbortProcess_Click);
            // 
            // BatchApprove
            // 
            this.BatchApprove.Location = new System.Drawing.Point(276, 20);
            this.BatchApprove.Name = "BatchApprove";
            this.BatchApprove.Size = new System.Drawing.Size(93, 23);
            this.BatchApprove.TabIndex = 13;
            this.BatchApprove.Text = "批量审批同意";
            this.BatchApprove.UseVisualStyleBackColor = true;
            this.BatchApprove.Click += new System.EventHandler(this.BatchApprove_Click);
            // 
            // DeploymentProcess
            // 
            this.DeploymentProcess.Location = new System.Drawing.Point(177, 20);
            this.DeploymentProcess.Name = "DeploymentProcess";
            this.DeploymentProcess.Size = new System.Drawing.Size(93, 23);
            this.DeploymentProcess.TabIndex = 12;
            this.DeploymentProcess.Text = "部署流程";
            this.DeploymentProcess.UseVisualStyleBackColor = true;
            this.DeploymentProcess.Click += new System.EventHandler(this.DeploymentProcess_Click);
            // 
            // ClearData
            // 
            this.ClearData.Location = new System.Drawing.Point(15, 20);
            this.ClearData.Name = "ClearData";
            this.ClearData.Size = new System.Drawing.Size(75, 23);
            this.ClearData.TabIndex = 1;
            this.ClearData.Text = "清空数据";
            this.ClearData.UseVisualStyleBackColor = true;
            this.ClearData.Click += new System.EventHandler(this.ClearData_Click);
            // 
            // EngineInfo
            // 
            this.EngineInfo.Location = new System.Drawing.Point(96, 20);
            this.EngineInfo.Name = "EngineInfo";
            this.EngineInfo.Size = new System.Drawing.Size(75, 23);
            this.EngineInfo.TabIndex = 11;
            this.EngineInfo.Text = "引擎信息";
            this.EngineInfo.UseVisualStyleBackColor = true;
            this.EngineInfo.Click += new System.EventHandler(this.EngineInfo_Click);
            // 
            // DataResult
            // 
            this.DataResult.Location = new System.Drawing.Point(15, 45);
            this.DataResult.Multiline = true;
            this.DataResult.Name = "DataResult";
            this.DataResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataResult.Size = new System.Drawing.Size(662, 183);
            this.DataResult.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.PMApprove);
            this.groupBox5.Controls.Add(this.DemoFunctionApprove);
            this.groupBox5.Controls.Add(this.DemoLeaderApprove);
            this.groupBox5.Controls.Add(this.DemoEnd);
            this.groupBox5.Controls.Add(this.DemoStart);
            this.groupBox5.Location = new System.Drawing.Point(13, 13);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(690, 55);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "流程示例-调账申请";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(535, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 11;
            this.label8.Text = "--------->";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(389, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "--------->";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(239, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "--------->";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "--------->";
            // 
            // PMApprove
            // 
            this.PMApprove.Location = new System.Drawing.Point(309, 21);
            this.PMApprove.Name = "PMApprove";
            this.PMApprove.Size = new System.Drawing.Size(75, 23);
            this.PMApprove.TabIndex = 4;
            this.PMApprove.Text = "PM审批";
            this.PMApprove.UseVisualStyleBackColor = false;
            this.PMApprove.Click += new System.EventHandler(this.PMApprove_Click);
            // 
            // DemoFunctionApprove
            // 
            this.DemoFunctionApprove.Location = new System.Drawing.Point(455, 21);
            this.DemoFunctionApprove.Name = "DemoFunctionApprove";
            this.DemoFunctionApprove.Size = new System.Drawing.Size(75, 23);
            this.DemoFunctionApprove.TabIndex = 3;
            this.DemoFunctionApprove.Text = "职能审批";
            this.DemoFunctionApprove.UseVisualStyleBackColor = false;
            this.DemoFunctionApprove.Click += new System.EventHandler(this.DemoFunctionApprove_Click);
            // 
            // DemoLeaderApprove
            // 
            this.DemoLeaderApprove.BackColor = System.Drawing.SystemColors.Control;
            this.DemoLeaderApprove.Location = new System.Drawing.Point(160, 21);
            this.DemoLeaderApprove.Name = "DemoLeaderApprove";
            this.DemoLeaderApprove.Size = new System.Drawing.Size(75, 23);
            this.DemoLeaderApprove.TabIndex = 2;
            this.DemoLeaderApprove.Text = "经理审批";
            this.DemoLeaderApprove.UseVisualStyleBackColor = false;
            this.DemoLeaderApprove.Click += new System.EventHandler(this.DemoLeaderApprove_Click);
            // 
            // DemoEnd
            // 
            this.DemoEnd.Location = new System.Drawing.Point(602, 21);
            this.DemoEnd.Name = "DemoEnd";
            this.DemoEnd.Size = new System.Drawing.Size(75, 23);
            this.DemoEnd.TabIndex = 1;
            this.DemoEnd.Text = "结束";
            this.DemoEnd.UseVisualStyleBackColor = false;
            // 
            // DemoStart
            // 
            this.DemoStart.Location = new System.Drawing.Point(15, 21);
            this.DemoStart.Name = "DemoStart";
            this.DemoStart.Size = new System.Drawing.Size(75, 23);
            this.DemoStart.TabIndex = 0;
            this.DemoStart.Tag = "";
            this.DemoStart.Text = "开始";
            this.DemoStart.UseVisualStyleBackColor = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ProcessId);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.QueryProcessIdTask);
            this.groupBox6.Controls.Add(this.AbortProcess);
            this.groupBox6.Controls.Add(this.GetProcess);
            this.groupBox6.Location = new System.Drawing.Point(13, 249);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(689, 51);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "其他";
            // 
            // ProcessId
            // 
            this.ProcessId.Location = new System.Drawing.Point(60, 20);
            this.ProcessId.Name = "ProcessId";
            this.ProcessId.Size = new System.Drawing.Size(245, 21);
            this.ProcessId.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "流程Id";
            // 
            // QueryProcessIdTask
            // 
            this.QueryProcessIdTask.Location = new System.Drawing.Point(454, 19);
            this.QueryProcessIdTask.Name = "QueryProcessIdTask";
            this.QueryProcessIdTask.Size = new System.Drawing.Size(121, 23);
            this.QueryProcessIdTask.TabIndex = 1;
            this.QueryProcessIdTask.Text = "查询流程Id代办";
            this.QueryProcessIdTask.UseVisualStyleBackColor = true;
            this.QueryProcessIdTask.Click += new System.EventHandler(this.QueryProcessIdTask_Click);
            // 
            // GetProcess
            // 
            this.GetProcess.Location = new System.Drawing.Point(581, 19);
            this.GetProcess.Name = "GetProcess";
            this.GetProcess.Size = new System.Drawing.Size(96, 23);
            this.GetProcess.TabIndex = 0;
            this.GetProcess.Text = "获取流程实例";
            this.GetProcess.UseVisualStyleBackColor = true;
            this.GetProcess.Click += new System.EventHandler(this.GetProcess_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(714, 554);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Flowable.Demo";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button StartProcess;
        private System.Windows.Forms.Button QueryUserNameTask;
        private System.Windows.Forms.Button ApproveTrue;
        private System.Windows.Forms.Button AbortProcess;
        private System.Windows.Forms.TextBox ProcessKey;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox StartProcessVariables;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TaskId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox DataResult;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button PMApprove;
        private System.Windows.Forms.Button DemoFunctionApprove;
        private System.Windows.Forms.Button DemoLeaderApprove;
        private System.Windows.Forms.Button DemoEnd;
        private System.Windows.Forms.Button DemoStart;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button QueryProcessIdTask;
        private System.Windows.Forms.Button GetProcess;
        private System.Windows.Forms.TextBox ProcessId;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button EngineInfo;
        private System.Windows.Forms.Button DeploymentProcess;
        private System.Windows.Forms.Button QueryProcessKeyTask;
        private System.Windows.Forms.TextBox ProcessIdApprove;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox PageSize;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox PageIndex;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button QueryTaskPaged;
        private System.Windows.Forms.Button ClearData;
        private System.Windows.Forms.Button QueryFinishedTask;
        private System.Windows.Forms.Button BatchApprove;
        private System.Windows.Forms.Button BatchAbortProcess;
        private System.Windows.Forms.Button Test;
    }
}

