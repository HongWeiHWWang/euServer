﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Flowable.Common;
using Flowable.Common.Models;
using Microsoft.VisualBasic;

namespace Flowable.Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 启动流程实例
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartProcess_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProcessKey.Text.Trim()))
            {
                MessageBox.Show("流程Key必填", "提示");
                return;
            }
            if (string.IsNullOrEmpty(StartProcessVariables.Text.Trim()))
            {
                MessageBox.Show("流程变量必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var variables = JsonConvert.DeserializeObject<List<ProcessVariable>>(StartProcessVariables.Text);
            variables.ForEach(x => x.Value = GetVariableValue(x.Value.ToString()));

            var businessId = Guid.NewGuid().ToString();
            var result = FlowableHelper.StartProcess(new StartProcessInput
            {
                Operator = "TestDemo",
                ProcessKey = ProcessKey.Text,
                BusinessId = businessId,
                Variables = variables
            });

            sb.AppendLine(string.Format("发起：启动工作流，流程Key【{0}】,业务Id【{1}】,变量集合【{2}】", ProcessKey.Text, businessId, StartProcessVariables.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            //设置窗体备用数据
            if (result.Success && result.Result.TaskList != null && result.Result.TaskList.Count > 0)
            {
                UserName.Text = result.Result.TaskList[0].UserName;
                TaskId.Text = result.Result.TaskList[0].TaskId;
                ProcessIdApprove.Text = result.Result.ProcessId;
                ProcessId.Text = result.Result.ProcessId;

                SetProcess(result.Result.TaskList[0].Key);
            }
        }

        /// <summary>
        /// 获取变量值
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private object GetVariableValue(string value)
        {
            value = value.Replace("\r\n", "").Replace(" ", "").Trim();
            if (value.StartsWith("[\"") && value.EndsWith("\"]"))
            {
                return JsonConvert.DeserializeObject<string[]>(value.ToString());
            }
            else if (value.ToLower() == "true" || value.ToLower() == "false")
            {
                return Convert.ToBoolean(value);
            }
            else
            {
                return value;
            }
        }

        private void ApproveTrue_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TaskId.Text.Trim()))
            {
                MessageBox.Show("代办Id必填", "提示");
                return;
            }

            if (string.IsNullOrEmpty(ProcessIdApprove.Text.Trim()))
            {
                MessageBox.Show("流程Id必填", "提示");
                return;
            }

            string reason = UserName.Text + "审批同意";
            reason = Interaction.InputBox("请输入意见", "意见", reason, -1, -1);

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var variables = JsonConvert.DeserializeObject<List<ProcessVariable>>(StartProcessVariables.Text);
            variables.ForEach(x => x.Value = GetVariableValue(x.Value.ToString()));

            var result = FlowableHelper.Approve(new ApproveInput
            {
                Operator = UserName.Text,
                TaskId = TaskId.Text,
                ProcessId = ProcessIdApprove.Text,
                Reason = reason,
                Variables = variables
            });

            sb.AppendLine(string.Format("发起：审批同意(流转)，代办Id【{0}】,流程Id【{1}】,意见：【{2}】", TaskId.Text, ProcessIdApprove.Text, reason));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            //设置窗体备用数据
            if (result.Success && result.Result != null && result.Result.TaskList != null && result.Result.TaskList.Count > 0)
            {
                var task = result.Result.TaskList.FirstOrDefault();
                if (task != null)
                {
                    UserName.Text = task.UserName;
                    TaskId.Text = task.TaskId;

                    SetProcess(task.Key);
                }
            }
            if (result.Success && result.Result != null)
            {
                if (result.Result.TaskList == null || result.Result.TaskList.Count == 0) SetProcess("End");
            }
        }

        private void GetProcess_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProcessId.Text.Trim()))
            {
                MessageBox.Show("流程Id必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.QueryProcess(ProcessId.Text);

            sb.AppendLine(string.Format("发起：获取流程实例，流程Id【{0}】", ProcessId.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }

        private void DataResultTextChanged()
        {
            DataResult.SelectionStart = DataResult.TextLength;
            DataResult.ScrollToCaret();
        }

        private void DemoLeaderApprove_Click(object sender, EventArgs e)
        {
            MessageBox.Show("串行会签(多人顺序审批)", "经理审批");
        }

        private void PMApprove_Click(object sender, EventArgs e)
        {
            MessageBox.Show("串行会签(多人顺序审批)", "PM审批");
        }

        private void DemoFunctionApprove_Click(object sender, EventArgs e)
        {
            MessageBox.Show("普通审批(可多人，一人审批节点结束)", "职能审批");
        }

        private void EngineInfo_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.EngineInfo();

            sb.AppendLine(string.Format("引擎信息:【{0}】", result));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }

        private void DeploymentProcess_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Multiselect = false;
            dialog.Title = "请选择.bpmn20.xml文件";
            dialog.Filter = "bpmn20.xml文件(*.bpmn20.xml)|*.xml";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(DataResult.Text);

                string file = dialog.FileName;
                var result = FlowableHelper.DeploymentProcess(file);

                sb.AppendLine(string.Format("部署流程定义:【{0}】", JsonConvert.SerializeObject(result)));
                sb.AppendLine("-".PadRight(106, '-'));

                DataResult.Text = sb.ToString();
                DataResultTextChanged();
            }
        }

        private void AbortProcess_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProcessId.Text.Trim()))
            {
                MessageBox.Show("流程Id必填", "提示");
                return;
            }

            var reason = "终止流程";
            reason = Interaction.InputBox("请输入理由", "理由", reason, -1, -1);

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.AbortProcess(UserName.Text, ProcessId.Text, reason);

            sb.AppendLine(string.Format("发起：终止流程(审批否决)，流程Id【{0}】，理由：【{1}】", ProcessId.Text, reason));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            if (result.Success)
            {
                UserName.Text = string.Empty;
                TaskId.Text = string.Empty;
                ProcessIdApprove.Text = string.Empty;

                SetProcess("End");
            }
        }

        private void QueryUserNameTask_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserName.Text.Trim()))
            {
                MessageBox.Show("用户名必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.QueryTasksByUserName(UserName.Text);

            sb.AppendLine(string.Format("发起：查询用户代办，用户名【{0}】", UserName.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            //设置窗体备用数据
            if (result.Success && result.Result != null && result.Result.Count > 0)
            {
                var task = result.Result.FirstOrDefault();
                if (task != null)
                {
                    TaskId.Text = task.TaskId;
                    ProcessIdApprove.Text = task.ProcessId;
                    ProcessId.Text = task.ProcessId;

                    SetProcess(task.Key);
                }
            }
        }

        private void QueryProcessIdTask_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProcessId.Text.Trim()))
            {
                MessageBox.Show("流程Id必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.QueryTasksByProcessId(ProcessId.Text);

            sb.AppendLine(string.Format("发起：查询流程Id代办，流程Id【{0}】", ProcessId.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            //设置窗体备用数据
            if (result.Success && result.Result != null && result.Result.Count > 0)
            {
                var task = result.Result.FirstOrDefault();
                if (task != null)
                {
                    UserName.Text = task.UserName;
                    TaskId.Text = task.TaskId;
                    ProcessIdApprove.Text = task.ProcessId;

                    SetProcess(task.Key);
                }
            }
        }

        private void QueryProcessKeyTask_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProcessKey.Text.Trim()))
            {
                MessageBox.Show("流程Key必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.QueryTasksByProcessKey(ProcessKey.Text);

            sb.AppendLine(string.Format("发起：查询流程Key代办，流程Key【{0}】", ProcessKey.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            //设置窗体备用数据
            if (result.Success && result.Result != null && result.Result.Count > 0)
            {
                var task = result.Result.FirstOrDefault();
                if (task != null)
                {
                    UserName.Text = task.UserName;
                    TaskId.Text = task.TaskId;
                    ProcessIdApprove.Text = task.ProcessId;
                    ProcessId.Text = task.ProcessId;

                    SetProcess(task.Key);
                }
            }
        }

        private void SetProcess(string activityKey)
        {
            switch (activityKey)
            {
                case "LeaderApprove":
                    DemoLeaderApprove.BackColor = SystemColors.Highlight;
                    PMApprove.BackColor = SystemColors.Control;
                    DemoFunctionApprove.BackColor = SystemColors.Control;
                    DemoEnd.BackColor = SystemColors.Control;
                    break;
                case "PMApprove":
                    DemoLeaderApprove.BackColor = SystemColors.Control;
                    PMApprove.BackColor = SystemColors.Highlight;
                    DemoFunctionApprove.BackColor = SystemColors.Control;
                    DemoEnd.BackColor = SystemColors.Control;
                    break;
                case "FunctionApprove":
                    DemoLeaderApprove.BackColor = SystemColors.Control;
                    PMApprove.BackColor = SystemColors.Control;
                    DemoFunctionApprove.BackColor = SystemColors.Highlight;
                    DemoEnd.BackColor = SystemColors.Control;
                    break;
                case "End":
                    DemoLeaderApprove.BackColor = SystemColors.Control;
                    PMApprove.BackColor = SystemColors.Control;
                    DemoFunctionApprove.BackColor = SystemColors.Control;
                    DemoEnd.BackColor = SystemColors.Highlight;
                    break;
                default:
                    DemoLeaderApprove.BackColor = SystemColors.Control;
                    PMApprove.BackColor = SystemColors.Control;
                    DemoFunctionApprove.BackColor = SystemColors.Control;
                    DemoEnd.BackColor = SystemColors.Control;
                    break;
            }
        }

        private void QueryTaskPaged_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserName.Text.Trim()))
            {
                MessageBox.Show("用户名必填", "提示");
                return;
            }
            if (string.IsNullOrEmpty(PageIndex.Text.Trim()))
            {
                MessageBox.Show("页码必填", "提示");
                return;
            }
            if (string.IsNullOrEmpty(PageSize.Text.Trim()))
            {
                MessageBox.Show("每页量必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.QueryTasksPaged(new QueryTaskPagedInput
            {
                PageIndex = Convert.ToInt32(PageIndex.Text),
                PageSize = Convert.ToInt32(PageSize.Text),
                ProcessKey = ProcessKey.Text,
                UserName = UserName.Text
            });

            sb.AppendLine(string.Format("发起：查询分页代办，用户名【{0}】，流程Key【{1}】，分页码【{2}】，每页量【{3}】", UserName.Text, ProcessKey.Text, PageIndex.Text, PageSize.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();

            //设置窗体备用数据
            if (result.Success && result.Result != null && result.Result.Total > 0)
            {
                var task = result.Result.Data.FirstOrDefault();
                if (task != null)
                {
                    TaskId.Text = task.TaskId;
                    ProcessIdApprove.Text = task.ProcessId;
                    ProcessId.Text = task.ProcessId;

                    SetProcess(task.Key);
                }
            }
        }

        private void ClearData_Click(object sender, EventArgs e)
        {
            DataResult.Text = string.Empty;
            DataResultTextChanged();
        }

        private void QueryFinishedTask_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserName.Text.Trim()))
            {
                MessageBox.Show("用户名必填", "提示");
                return;
            }
            if (string.IsNullOrEmpty(PageIndex.Text.Trim()))
            {
                MessageBox.Show("分页码必填", "提示");
                return;
            }
            if (string.IsNullOrEmpty(PageSize.Text.Trim()))
            {
                MessageBox.Show("每页量必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            var result = FlowableHelper.QueryFinishedTasksPaged(new QueryFinishedTaskPagedInput
            {
                PageIndex = Convert.ToInt32(PageIndex.Text),
                PageSize = Convert.ToInt32(PageSize.Text),
                ProcessKey = ProcessKey.Text,
                UserName = UserName.Text
            });

            sb.AppendLine(string.Format("发起：查询分页已办，用户名【{0}】，流程Key【{1}】，分页码【{2}】，每页量【{3}】", UserName.Text, ProcessKey.Text, PageIndex.Text, PageSize.Text));
            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));
            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }

        private void BatchApprove_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserName.Text.Trim()))
            {
                MessageBox.Show("用户名必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            sb.AppendLine(string.Format("发起：批量审批同意，用户名【{0}】", UserName.Text));

            var queryTaskResult = FlowableHelper.QueryTasksByUserName(UserName.Text);

            if (queryTaskResult.Success && queryTaskResult.Result != null && queryTaskResult.Result.Count > 0)
            {
                sb.AppendLine(string.Format("用户名【{0}】共有【{1}】个代办", UserName.Text, queryTaskResult.Result.Count));

                var reason = UserName.Text + "审批同意";
                reason = Interaction.InputBox("请输入意见", "意见", reason, -1, -1);

                var approveResult = FlowableHelper.BatchApprove(queryTaskResult.Result.Select(x => new ApproveInput
                {
                    Operator = UserName.Text,
                    TaskId = x.TaskId,
                    ProcessId = x.ProcessId,
                    Reason = reason,
                    Variables = null
                }).ToList());

                sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(approveResult)));
            }
            else
            {
                sb.AppendLine(string.Format("用户名【{0}】没有代办", UserName.Text));
            }

            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }

        private void BatchAbortProcess_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(UserName.Text.Trim()))
            {
                MessageBox.Show("用户名必填", "提示");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            sb.AppendLine(string.Format("发起：批量终止流程，用户名【{0}】", UserName.Text));

            var queryTaskResult = FlowableHelper.QueryTasksByUserName(UserName.Text);

            if (queryTaskResult.Success && queryTaskResult.Result != null && queryTaskResult.Result.Count > 0)
            {
                sb.AppendLine(string.Format("用户名【{0}】共有【{1}】个代办流程", UserName.Text, queryTaskResult.Result.Count));

                var reason = UserName.Text + "终止流程";
                reason = Interaction.InputBox("请输入意见", "意见", reason, -1, -1);

                var processIds = queryTaskResult.Result.Select(x => x.ProcessId).Distinct().ToArray();
                var abortResult = FlowableHelper.BatchAbortProcess(UserName.Text, processIds, reason);

                sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(abortResult)));
            }
            else
            {
                sb.AppendLine(string.Format("用户名【{0}】没有代办流程", UserName.Text));
            }

            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }

        private void Test_Click(object sender, EventArgs e)
        {
            //var userName = "TestUser" + Convert.ToInt64((DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds).ToString();
            //QueryUser(userName);

            //QueryProcessDefinition("AdjustApplication:11:bb56ffc4-7f30-11ea-8e90-0a0027000002");

            FlowableHelper.QueryLatestProcessDefinition("AdjustApplication");
        }

        private void QueryProcessDefinition(string processDefinitionId)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            sb.AppendLine(string.Format("发起：查询流程定义，流程定义Id【{0}】", processDefinitionId));

            var result = FlowableHelper.QueryProcessDefinition(processDefinitionId);

            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));

            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }

        private void QueryUser(string userName)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(DataResult.Text);

            sb.AppendLine(string.Format("发起：查询用户，用户名【{0}】", userName));

            var result = FlowableHelper.QueryUser(userName);

            sb.AppendLine(string.Format("结果：【{0}】", JsonConvert.SerializeObject(result)));

            sb.AppendLine("-".PadRight(106, '-'));

            DataResult.Text = sb.ToString();
            DataResultTextChanged();
        }
    }
}
