package samsundot.flowablesdk.api.controller;

import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import samsundot.flowablesdk.common.FlowableHelper;
import samsundot.flowablesdk.common.model.*;
import samsundot.flowablesdk.common.wab.AjaxResponse;

import java.util.List;

@RestController
@RequestMapping(path = "/flawable")
public class FlawableController {

    @ApiOperation(value = "1.发起流程")
    @PostMapping(value = "/startProcess")
    public AjaxResponse<StartProcessOutput> startProcess(@RequestBody StartProcessInput start){
        return  FlowableHelper.startProcess(start);
    }
    @ApiOperation(value = "2.查询任务")
    @PostMapping(value = "/queryTasks")
    public AjaxResponse<List<QueryTaskOutput>> queryTasks(String processId, String processKey, String userName){
        return  FlowableHelper.queryTasks(processId,processKey,userName);
    }
    @ApiOperation(value = "2.查询流程Id任务")
    @PostMapping(value = "/queryTasksByProcessId")
    public AjaxResponse<List<QueryTaskOutput>> queryTasksByProcessId(String processId){
        return  FlowableHelper.queryTasksByProcessId(processId);
    }

    @ApiOperation(value = "3.审核任务")
    @PostMapping(value = "/approve")
    public AjaxResponse<ApproveOutput> approve(@RequestBody ApproveInput approve){
        return  FlowableHelper.approve(approve);
    }
    @ApiOperation(value = "4.终止任务")
    @PostMapping(value = "/abortProcess")
    public AjaxResponse<QueryProcessOutput> abortProcess(String operatorUserName,String processId,String reason){
        return  FlowableHelper.abortProcess(operatorUserName,processId,reason);
    }

    @ApiOperation(value = "查询进程")
    @PostMapping(value = "/queryProcess")
    public AjaxResponse<QueryProcessOutput> queryProcess(String processId, boolean isReturnTask){
        return  FlowableHelper.queryProcess(processId,isReturnTask);
    }
    @ApiOperation(value = "删除流程")
    @PostMapping(value = "/deleteProcess")
    public   AjaxResponse<Boolean> deleteProcess(String processId, String reason){
        return  FlowableHelper.deleteProcess(processId,reason);
    }
    @ApiOperation(value = "流程节点跳转")
    @PostMapping(value = "/processActivityJump")
    public   AjaxResponse<Boolean> processActivityJump(String processId, String currentActivityKey, String targetActivityKey, String reason) {
        return FlowableHelper.processActivityJump(processId,currentActivityKey,targetActivityKey,reason);
    }

    @ApiOperation(value = "查询代办(支持：用户名、流程Key、分页)")
    @PostMapping(value = "/queryTasksPaged")
    public   AjaxResponse<QueryTaskPagedOutput> queryTasksPaged(@RequestBody QueryTaskPagedInput query){
        return FlowableHelper.queryTasksPaged(query);
    }
    @ApiOperation(value = "插入代办评论")
    @PostMapping(value = "/insertTaskComment")
    public   AjaxResponse<Boolean> insertTaskComment(String operator,String taskId, String comment) {
        return FlowableHelper.insertTaskComment(operator,taskId,comment);
    }
    @ApiOperation(value = "查询代办评论")
    @PostMapping(value = "/queryTaskComment")
    public   AjaxResponse<List<QueryTaskCommentOutput>> queryTaskComment(String processId) {
        return FlowableHelper.queryTaskComment(processId);
    }
    @ApiOperation(value = "查询历史代办")
    @PostMapping(value = "/queryHistoricTask")
    public   AjaxResponse<List<QueryHistoricTaskOutput>> queryHistoricTask(String processId){
        return FlowableHelper.queryHistoricTask(processId);
    }
    @ApiOperation(value = "查询已办(支持：用户名、流程Key、分页)")
    @PostMapping(value = "/queryFinishedTasksPaged")
    public AjaxResponse<QueryFinishedTaskPagedOutput> queryFinishedTasksPaged(@RequestBody QueryFinishedTaskPagedInput query){
        return FlowableHelper.queryFinishedTasksPaged(query);
    }
    @ApiOperation(value = "批量审核")
    @PostMapping(value = "/batchApprove")
    public  AjaxResponse<List<AjaxResponse<ApproveOutput>>> batchApprove(@RequestBody List<ApproveInput> approveList){
        return FlowableHelper.batchApprove(approveList);
    }
    @ApiOperation(value = "批量终止")
    @PostMapping(value = "/batchAbort")
    public AjaxResponse<List<AjaxResponse<QueryProcessOutput>>> batchAbortProcess(String operatorUserName,String[] processIds, String reason){
        return FlowableHelper.batchAbortProcess(operatorUserName,processIds,reason);
    }
    @ApiOperation(value = "检查用户存在")
    @GetMapping(value = "/checkUserExist")
    public AjaxResponse<Boolean> checkUserExist(String userName){
        return FlowableHelper.checkUserExist(userName);
    }
    @ApiOperation(value = "创建用户")
    @GetMapping(value = "/createUser")
    public AjaxResponse<Boolean> createUser(String userName){
        return FlowableHelper.createUser(userName);
    }
    @ApiOperation(value = "查询用户")
    @GetMapping(value = "/queryUser")
    public AjaxResponse<QueryUserOutput> queryUser(String userName){
        return FlowableHelper.queryUser(userName);
    }
    @ApiOperation(value = "查询最新的流程定义")
    @GetMapping(value = "/queryLatestProcessDefinition")
    public AjaxResponse<QueryProcessDefinitionOutput> queryLatestProcessDefinition(String processKey){
        return FlowableHelper.queryLatestProcessDefinition(processKey);
    }
    @ApiOperation(value = "查询流程定义")
    @GetMapping(value = "/queryProcessDefinition")
    public  AjaxResponse<QueryProcessDefinitionOutput> queryProcessDefinition(String processDefinitionId){
        return FlowableHelper.queryProcessDefinition(processDefinitionId);
    }




}
