//package samsundot.flowablesdk.common.model.flowable;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.apache.commons.collections.CollectionUtils;
//import samsundot.flowablesdk.common.model.ProcessVariable;
//import samsundot.flowablesdk.common.model.StartProcessVariable;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class FlowableStartProcessVariable {
//    private String name;
//    private Object value;
//
//    public FlowableStartProcessVariable(ProcessVariable startProcessVariable) {
//        if (startProcessVariable != null) {
//            this.name = startProcessVariable.getName();
//            this.value = startProcessVariable.getValue();
//        }
//    }
//}
