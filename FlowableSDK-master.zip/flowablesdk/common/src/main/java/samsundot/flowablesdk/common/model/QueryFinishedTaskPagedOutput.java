package samsundot.flowablesdk.common.model;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Accessors(chain = true)
@Data
public class QueryFinishedTaskPagedOutput {
    private int total;

    private List<QueryFinishedTaskOutput> data;
}
