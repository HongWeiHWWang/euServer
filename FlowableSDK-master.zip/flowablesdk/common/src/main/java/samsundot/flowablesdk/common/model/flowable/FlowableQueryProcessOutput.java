package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.Date;


@Data
public class FlowableQueryProcessOutput {
    private String id;
    private String businessKey;
    private String processDefinitionId;
    private String processDefinitionName;
    private Date startTime;
    private Date endTime;
    private String startUserId;
}
