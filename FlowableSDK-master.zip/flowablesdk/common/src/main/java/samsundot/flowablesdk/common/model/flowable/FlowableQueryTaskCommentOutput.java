package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.Date;

@Data
public class FlowableQueryTaskCommentOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String taskId ;

    /// <summary>
    /// 评论
    /// </summary>
    private String message ;

    /// <summary>
    /// 时间
    /// </summary>
    private Date time ;

}
