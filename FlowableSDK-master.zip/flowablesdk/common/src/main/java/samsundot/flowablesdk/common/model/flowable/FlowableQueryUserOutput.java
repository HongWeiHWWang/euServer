package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 描述：
 *
 * @ClassName FlowableQueryUserOutput
 * @Author jiangwy
 * @Date 2020/5/6 16:19
 **/
@Data
@NoArgsConstructor
public class FlowableQueryUserOutput {
    private String id;
    private String email;
}
