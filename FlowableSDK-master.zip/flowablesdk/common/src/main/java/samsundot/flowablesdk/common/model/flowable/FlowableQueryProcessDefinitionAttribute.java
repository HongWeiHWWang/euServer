package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionAttribute
 * @Author jiangwy
 * @Date 2020/5/7 0:18
 **/
@Data
public class FlowableQueryProcessDefinitionAttribute {
    private String name;
    private String value;
}
