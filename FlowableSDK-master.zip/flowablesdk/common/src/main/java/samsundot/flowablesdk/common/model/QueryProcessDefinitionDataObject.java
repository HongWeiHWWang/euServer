package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * 描述：
 *
 * @ClassName QueryProcessDefinitionDataObject
 * @Author jiangwy
 * @Date 2020/5/6 23:42
 **/
@Accessors(chain = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProcessDefinitionDataObject {
    /// <summary>
    /// 数据对象Id
    /// </summary>
    private String id;

    /// <summary>
    /// 数据对象名称
    /// </summary>
    private String name ;

    /// <summary>
    /// 数据对象值
    /// </summary>
    private Object value ;

    /// <summary>
    /// 数据对象类型（string、boolean、datetime、double、int、long）
    /// </summary>
    private String type ;
}
