package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionDataObject
 * @Author jiangwy
 * @Date 2020/5/7 0:15
 **/
@Data
public class FlowableQueryProcessDefinitionDataObject {
    private String id ;

    private String name ;

    private Object value ;

    private String type ;
}
