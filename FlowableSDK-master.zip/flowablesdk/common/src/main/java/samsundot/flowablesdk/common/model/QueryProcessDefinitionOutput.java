package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * 描述：
 *
 * @ClassName QueryProcessDefinitionOutput
 * @Author jiangwy
 * @Date 2020/5/6 23:41
 **/
@Accessors( chain = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProcessDefinitionOutput {
    /// <summary>
    /// 流程Key
    /// </summary>
    public String processKey;

    /// <summary>
    /// 流程名
    /// </summary>
    public String processName;

    /// <summary>
    /// 数据对象列表
    /// </summary>
    public List<QueryProcessDefinitionDataObject> dataObjectList;

    /// <summary>
    /// 流程节点列表
    /// </summary>
    public List<QueryProcessDefinitionFlowElement> flowElementList;
}
