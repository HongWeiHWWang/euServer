package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.Dictionary;
import java.util.List;
import java.util.Map;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionFlowElement
 * @Author jiangwy
 * @Date 2020/5/7 0:17
 **/
@Data
public class FlowableQueryProcessDefinitionFlowElement {
    private String id ;

    private String name ;

    private String assignee ;

    private Map<String,List<FlowableQueryProcessDefinitionAttribute>> attributes ;

    private List<FlowableQueryProcessDefinitionInOutFlow> incomingFlows ;

    private List<FlowableQueryProcessDefinitionInOutFlow> outgoingFlows ;

    private FlowableQueryProcessDefinitionLoopCharacteristic loopCharacteristics ;
}
