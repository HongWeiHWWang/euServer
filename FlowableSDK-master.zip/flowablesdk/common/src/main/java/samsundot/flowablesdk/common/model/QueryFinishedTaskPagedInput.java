package samsundot.flowablesdk.common.model;

import lombok.Data;

@Data
public class QueryFinishedTaskPagedInput {
    /// <summary>
    /// 页码(默认1)
    /// </summary>
    private int pageIndex ;

    /// <summary>
    /// 每页数量(默认10)
    /// </summary>
    private int pageSize ;

    /// <summary>
    /// 用户名
    /// </summary>
    private String userName ;

    /// <summary>
    /// 流程Key
    /// </summary>
    private String processKey ;

    public QueryFinishedTaskPagedInput() {
        this.pageIndex = 1;
        this.pageSize = 10;
    }
}
