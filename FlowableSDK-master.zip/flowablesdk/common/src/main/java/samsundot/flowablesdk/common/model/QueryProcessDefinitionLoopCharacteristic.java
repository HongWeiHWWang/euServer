package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * 描述：
 *
 * @ClassName QueryProcessDefinitionLoopCharacteristic
 * @Author jiangwy
 * @Date 2020/5/6 23:51
 **/
@Accessors(chain = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProcessDefinitionLoopCharacteristic {
    /// <summary>
    /// 集合变量
    /// </summary>
    private String listVariable;

    /// <summary>
    /// 完成条件
    /// </summary>
    private String completionCondition;

    /// <summary>
    /// 元素变量
    /// </summary>
    private String elementVariable;

    /// <summary>
    /// 是否顺序
    /// </summary>
    private Boolean isSequential;
}
