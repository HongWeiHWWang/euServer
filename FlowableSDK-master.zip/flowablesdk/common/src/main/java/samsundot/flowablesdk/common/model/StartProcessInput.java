package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import java.util.List;


@AllArgsConstructor
@Data
public class StartProcessInput {

    /// <summary>
    /// 操作人
    /// </summary>
    public String operator;
    /// <summary>
    /// 流程Key
    /// </summary>
    private String processKey;
    /**
     * 业务ID
     */
    private String businessId;

    /// <summary>
    /// 动态变量集合
    /// </summary>
    private List<ProcessVariable> variables;

    /// <summary>
    /// 是否返回代办（默认是）
    /// </summary>
    private boolean returnTask;
    public StartProcessInput(){
        returnTask=true;
    }

    public void setOperator(String operator) {
        if (!StringUtils.isEmpty(operator)){
            this.operator = operator.toLowerCase();
        }else{
            this.operator=operator;
        }
    }
}
