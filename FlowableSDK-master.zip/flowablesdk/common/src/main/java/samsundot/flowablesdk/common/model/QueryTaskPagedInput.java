package samsundot.flowablesdk.common.model;

import lombok.Data;

@Data
public class QueryTaskPagedInput {
    /// <summary>
    /// 页码(默认1)
    /// </summary>
    private int PageIndex ;

    /// <summary>
    /// 每页数量(默认10)
    /// </summary>
    private int PageSize;

    /// <summary>
    /// 用户名
    /// </summary>
    private String UserName;

    /// <summary>
    /// 流程Key
    /// </summary>
    private String ProcessKey;

    public QueryTaskPagedInput() {
        PageIndex = 1;
        PageSize = 10;
    }
}
