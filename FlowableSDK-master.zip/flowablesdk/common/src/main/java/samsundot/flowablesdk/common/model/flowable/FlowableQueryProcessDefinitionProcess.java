package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionProcess
 * @Author jiangwy
 * @Date 2020/5/7 0:13
 **/
@Data
public class FlowableQueryProcessDefinitionProcess {
    private String id ;

    private String name ;

    private List<FlowableQueryProcessDefinitionDataObject> dataObjects ;

    private Map<String, FlowableQueryProcessDefinitionFlowElement> flowElementMap ;
}
