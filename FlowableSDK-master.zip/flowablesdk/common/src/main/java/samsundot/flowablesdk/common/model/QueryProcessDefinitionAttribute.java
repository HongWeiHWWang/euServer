package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * 描述：
 *
 * @ClassName QueryProcessDefinitionAttribute
 * @Author jiangwy
 * @Date 2020/5/6 23:47
 **/
@Accessors(chain = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProcessDefinitionAttribute {
    /// <summary>
    /// 属性名
    /// </summary>
    private String name;

    /// <summary>
    /// 属性值
    /// </summary>
    private String value;
}
