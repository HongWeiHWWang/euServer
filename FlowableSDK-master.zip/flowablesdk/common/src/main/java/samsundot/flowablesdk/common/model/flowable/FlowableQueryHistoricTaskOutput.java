package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.List;

@Data
public class FlowableQueryHistoricTaskOutput {
    private List<FlowableQueryHistoricTaskDataOutput> data;
    private int total ;
}
