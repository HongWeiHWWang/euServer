package samsundot.flowablesdk.common.model.flowable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import samsundot.flowablesdk.common.model.ProcessVariable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlowableProcessVariable {
    private String name;
    private Object value;

    public FlowableProcessVariable(ProcessVariable startProcessVariable) {
        if (startProcessVariable != null) {
            this.name = startProcessVariable.getName();
            this.value = startProcessVariable.getValue();
        }
    }
}
