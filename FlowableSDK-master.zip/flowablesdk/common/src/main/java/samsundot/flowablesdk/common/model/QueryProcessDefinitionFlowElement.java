package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * 描述：
 *
 * @ClassName QueryProcessDefinitionFlowElement
 * @Author jiangwy
 * @Date 2020/5/6 23:44
 **/
@Accessors(chain = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProcessDefinitionFlowElement {
    /// <summary>
    /// 节点Key
    /// </summary>
    public String key ;

    /// <summary>
    /// 节点名
    /// </summary>
    public String name ;

    /// <summary>
    /// 分配人
    /// </summary>
    public String assignee ;

    /// <summary>
    /// 属性列表（自定义）
    /// </summary>
    public List<QueryProcessDefinitionAttribute> attributeList;

    /// <summary>
    /// 传入流程列表
    /// </summary>
    public List<QueryProcessDefinitionInOutFlow> incomingFlowList ;

    /// <summary>
    /// 传出流程列表
    /// </summary>
    public List<QueryProcessDefinitionInOutFlow> outgoingFlowList ;

    /// <summary>
    /// 循环特性
    /// </summary>
    public QueryProcessDefinitionLoopCharacteristic loopCharacteristic ;
}
