package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionLoopCharacteristic
 * @Author jiangwy
 * @Date 2020/5/7 0:20
 **/
@Data
public class FlowableQueryProcessDefinitionLoopCharacteristic {
    private String inputDataItem ;

    private String completionCondition ;

    private String elementVariable ;

    private Boolean sequential ;
}
