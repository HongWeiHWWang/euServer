package samsundot.flowablesdk.common.model.flowable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FlowableQueryTaskDataOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String id ;
    /**
     * 审核人
     */
    private String assignee;

    /// <summary>
    /// 流程Id
    /// </summary>
    private String processInstanceId ;

    /// <summary>
    /// 流程节点名
    /// </summary>
    private String name ;

    /// <summary>
    /// 流程节点Key
    /// </summary>
    private String taskDefinitionKey ;


    /// <summary>
    /// 流程定义Id
    /// </summary>
    public String processDefinitionId;
    /**
     * 创建时间
     */
    private Date createTime;
}
