package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;
import samsundot.flowablesdk.common.model.QueryTaskCommentOutput;

import java.util.Date;
import java.util.List;

@Data
public class FlowableQueryHistoricTaskDataOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String id ;

    /// <summary>
    /// 流程节点名
    /// </summary>
    private String name ;

    /// <summary>
    /// 流程节点Key
    /// </summary>
    private String taskDefinitionKey ;

    /// <summary>
    /// 代办人
    /// </summary>
    private String assignee ;

    /// <summary>
    /// 代办开始时间
    /// </summary>
    private Date  startTime ;

    /// <summary>
    /// 代办结束时间
    /// </summary>
    private Date endTime ;

    /// <summary>
    /// 评论
    /// </summary>
    private List<QueryTaskCommentOutput> commentList ;

    /// <summary>
    /// 代办删除原因
    /// </summary>
    private String deleteReason ;
}
