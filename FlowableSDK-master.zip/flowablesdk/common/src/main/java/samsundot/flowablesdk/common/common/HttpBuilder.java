package samsundot.flowablesdk.common.common;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import samsundot.flowablesdk.common.wab.AjaxResponse;
import samsundot.flowablesdk.common.wab.AjaxResponseUtils;

import java.util.function.Function;

@NoArgsConstructor
@Accessors(chain = true)
@Data
public class HttpBuilder {
    private String path;
    private String token;
    private HttpMethod method= HttpMethod.GET;
    public HttpBuilder(String path) {
        this.path = path;
    }
    public static HttpBuilder beginRequest(String path){
        return new HttpBuilder(path);
    }
    public <T,R> ResponseEntity<T> execute(R r, Class<T> responseType){
        String thisUrl=String.format("%s%s",FlowableHelperBase.getBaseUrl(), path);
        String thisToken= StringUtils.isEmpty(token)?FlowableHelperBase.getTOKEN():token;
        return FlowableHelperBase.exchange(thisUrl,method,r,responseType,thisToken);
    }
    public <T> ResponseEntity<T> execute(Class<T> responseType) {
        return this.execute(null, responseType);
    }
    public <R> ResponseEntity<JSONObject> execute(R r) {
        return this.execute(r, JSONObject.class);
    }

    /**
     * @Author jiangwy
     * @Description 返回结果集
     * @Date  2020/4/1 18:58
     **/
    public <T,R> AjaxResponse<T> executeAjaxResponse(R r, Class<T> responseType){
        try{
            ResponseEntity<T> responseEntity= execute(r,responseType);
            return AjaxResponseUtils.result(responseEntity);
        } catch (HttpClientErrorException ex) {
            return AjaxResponseUtils.result(ex.getStatusCode());
        } catch (Exception ex) {
            return AjaxResponseUtils.error(ex);
        }
    }
    public <T> AjaxResponse<T> executeAjaxResponse(Class<T> responseType) {
        return this.executeAjaxResponse(null, responseType);
    }
    public <R> AjaxResponse<Object> executeAjaxResponse(R r) {
        return this.executeAjaxResponse(r, Object.class);
    }

    public <R> AjaxResponse<Object> executeAjaxResponse() {
        return this.executeAjaxResponse("", Object.class);
    }
    /**
     * @Author jiangwy
     * @Description 返回结果集待类型转换的
     * @Date  2020/4/1 18:58
     **/
    public <T,TR,R> AjaxResponse<TR> executeAjaxResponse(R r, Class<T> responseType, Function<T, TR> function){
        try{
            ResponseEntity<T> responseEntity= execute(r,responseType);
            if (function!=null){
                TR tr= function.apply(responseEntity.getBody());
                return AjaxResponseUtils.success(tr);
            }else{
                return AjaxResponseUtils.result(responseEntity.getStatusCode());
            }
        } catch (HttpClientErrorException ex) {
            return AjaxResponseUtils.result(ex.getStatusCode());
        }catch (Exception ex) {
            return AjaxResponseUtils.error(ex);
        }
    }
    /**
     * @Author jiangwy
     * @Description 返回结果集待类型转换的
     * @Date  2020/4/1 19:20
     **/
    public <T,TR> AjaxResponse<TR> getAjaxResponse(Class<T> responseType, Function<T, TR> function) {
        return this.executeAjaxResponse("", responseType,function);
    }
    /**
     * @Author jiangwy
     * @Description 返回结果集待类型转换的
     * @Date  2020/4/1 19:20
     **/
    public <R,TR> AjaxResponse<TR> putAjaxResponse(R r, Function<JSONObject, TR> function) {
        return this.executeAjaxResponse(r, JSONObject.class,function);
    }
}
