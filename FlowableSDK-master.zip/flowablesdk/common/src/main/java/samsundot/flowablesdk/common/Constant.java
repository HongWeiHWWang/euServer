package samsundot.flowablesdk.common;

public class Constant {
    public final static String  START_PROCESS= "/flowable-rest/service/runtime/process-instances";
    public final static String  QUERY_TASKS= "/flowable-rest/service/query/tasks";
    public final static String  APPROVE= "/flowable-rest/service/runtime/tasks";
    public final static String  ABORT_PROCESS= "/flowable-rest/service/runtime/process-instances";
    public final static String QUERY_PROCESS="/flowable-rest/service/history/historic-process-instances";



}
