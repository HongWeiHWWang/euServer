package samsundot.flowablesdk.common.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import samsundot.flowablesdk.common.model.flowable.FlowableQueryProcessOutput;

import java.util.Date;
import java.util.List;

@Accessors(chain = true)
@NoArgsConstructor
@Data
public class QueryProcessOutput {
    /// <summary>
    /// 流程Id
    /// </summary>
    private String processId ;

    /// <summary>
    /// 业务Id
    /// </summary>
    private String businessId ;
    /// <summary>
    /// 流程定义Id
    /// </summary>
    private String processDefinitionId;

    /// <summary>
    /// 流程名称
    /// </summary>
    private String processName ;

    /// <summary>
    /// 开始时间
    /// </summary>
    private Date startTime ;

    /// <summary>
    /// 结束时间
    /// </summary>
    private Date endTime ;

    /// <summary>
    /// 流程创建人
    /// </summary>
    private String startUserName;


    /// <summary>
    /// 当前节点Key
    /// </summary>
    private String currentActivityKey ;

    /// <summary>
    /// 历史代办
    /// </summary>
    private List<QueryHistoricTaskOutput> historicTaskList ;
/**
 *流程定义
 * @param
 * @author jiangwy
 * @return
 */
    private QueryProcessDefinitionOutput processDefinition;

    public QueryProcessOutput(FlowableQueryProcessOutput flowableQueryProcessOutput) {
        this.processId = flowableQueryProcessOutput.getId();
        this.businessId = flowableQueryProcessOutput.getBusinessKey();
        this.processDefinitionId=flowableQueryProcessOutput.getProcessDefinitionId();
        this.processName = flowableQueryProcessOutput.getProcessDefinitionName();
        this.startTime = flowableQueryProcessOutput.getStartTime();
        this.endTime = flowableQueryProcessOutput.getEndTime();
        this.startUserName=flowableQueryProcessOutput.getStartUserId();
    }
}
