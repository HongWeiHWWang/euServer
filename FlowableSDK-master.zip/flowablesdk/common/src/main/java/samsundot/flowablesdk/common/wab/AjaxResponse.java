package samsundot.flowablesdk.common.wab;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Accessors(chain = true)
@Data
public class AjaxResponse<TResult> {
    private TResult result;
    private boolean success;
    private ErrorInfo error;

    public AjaxResponse(boolean success,TResult result) {
        this.result = result;
        this.success=success;
    }
    public AjaxResponse() {
        success=true;
    }
    public AjaxResponse(boolean success)
    {
        this.success = success;
    }

    public AjaxResponse(AjaxResponse<?> ajaxResponse) {
        this.success = ajaxResponse.isSuccess();
        this.error=ajaxResponse.getError();
    }
}
