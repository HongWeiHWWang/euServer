package samsundot.flowablesdk.common.model.flowable;

import samsundot.flowablesdk.common.model.NameValueOperation;

import java.util.ArrayList;
import java.util.List;


public class FlowableQueryFinishedTaskPagedInput {
    /// <summary>
    /// 起始数
    /// </summary>
    private int start ;

    /// <summary>
    /// 每页数量
    /// </summary>
    private int size ;

    /// <summary>
    /// 用户名
    /// </summary>
    private String taskAssignee ;

    /// <summary>
    /// 流程Key
    /// </summary>
    private String processDefinitionKey ;

    /// <summary>
    /// 是否完成的代办（只读默认值是true）
    /// </summary>
    private boolean finished ;

    /// <summary>
    /// 流程变量（只读默认值是审批通过变量）
    /// </summary>
    private List<NameValueOperation> processVariables;

    public FlowableQueryFinishedTaskPagedInput() {
        finished=true;
        processVariables=new ArrayList<>();
        processVariables.add(new NameValueOperation("approved",true,"equals"));
    }

    public boolean isFinished() {
        return finished;
    }

    public List<NameValueOperation> getProcessVariables() {
        return processVariables;
    }

    public int getStart() {
        return start;
    }

    public FlowableQueryFinishedTaskPagedInput setStart(int start) {
        this.start = start;
        return this;
    }

    public int getSize() {
        return size;
    }

    public FlowableQueryFinishedTaskPagedInput setSize(int size) {
        this.size = size;
        return this;
    }

    public String getTaskAssignee() {
        return taskAssignee;
    }

    public FlowableQueryFinishedTaskPagedInput setTaskAssignee(String taskAssignee) {
        this.taskAssignee = taskAssignee;
        return this;
    }

    public String getProcessDefinitionKey() {
        return processDefinitionKey;
    }

    public FlowableQueryFinishedTaskPagedInput setProcessDefinitionKey(String processDefinitionKey) {
        this.processDefinitionKey = processDefinitionKey;
        return this;
    }
}
