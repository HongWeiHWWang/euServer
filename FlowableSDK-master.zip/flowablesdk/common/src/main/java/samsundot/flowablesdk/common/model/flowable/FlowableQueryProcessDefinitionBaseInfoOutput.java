package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionBaseInfoOutput
 * @Author jiangwy
 * @Date 2020/5/7 1:11
 **/
@Data
public class FlowableQueryProcessDefinitionBaseInfoOutput {
    private String id ;

    private String key ;

    private int version ;

    private String name ;
}
