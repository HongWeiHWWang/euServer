package samsundot.flowablesdk.common.model;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Accessors(chain = true)
@Data
public class QueryFinishedTaskOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String taskId ;

    /// <summary>
    /// 用户名
    /// </summary>
    private String userName ;

    /// <summary>
    /// 流程Id
    /// </summary>
    private String processId ;

    /// <summary>
    /// 流程节点名
    /// </summary>
    private String name ;

    /// <summary>
    /// 流程节点Key
    /// </summary>
    private String key ;

    /// <summary>
    /// 代办开始时间
    /// </summary>
    private Date startTime ;

    /// <summary>
    /// 代办结束时间
    /// </summary>
    private Date  endTime ;
}
