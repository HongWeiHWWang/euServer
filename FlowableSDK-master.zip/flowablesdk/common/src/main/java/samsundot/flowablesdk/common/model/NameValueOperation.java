package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class NameValueOperation {
    private String name;
    private Object value;
    private String Operation;
}
