package samsundot.flowablesdk.common.wab;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public abstract class AjaxResponseUtils {
    public  static <T>  AjaxResponse<T> success(){
        return new AjaxResponse<T>(true);
    }
    public  static <T>  AjaxResponse<T> success(T t){
        return new AjaxResponse<T>(true,t);
    }
    public  static <T>  AjaxResponse<T> result(ResponseEntity<T> responseEntity){
        if (responseEntity.getStatusCode()==HttpStatus.OK||responseEntity.getStatusCode()==HttpStatus.CREATED) {
            return new AjaxResponse<T>(true, responseEntity.getBody());
        }else {
            ErrorInfo errorInfo=new ErrorInfo(String.valueOf(responseEntity.getStatusCode().value()),
                    responseEntity.getStatusCode().name());
            return new AjaxResponse<T>(false).setError(errorInfo);
        }
    }
    public  static <T>  AjaxResponse<T> result(HttpStatus httpStatus){
        ErrorInfo errorInfo=new ErrorInfo(String.valueOf(httpStatus.value()),httpStatus.name());
        return new AjaxResponse<T>(httpStatus==HttpStatus.OK||httpStatus==HttpStatus.CREATED).setError(errorInfo);
    }
    public static <T> AjaxResponse<T> result(AjaxResponse<?> ajaxResponse){
        return new AjaxResponse<T>(ajaxResponse);
    }
    public static <T> AjaxResponse<T> result(AjaxResponse<?> ajaxResponse,T t){
        AjaxResponse<T> ajaxResponse1 = new AjaxResponse<>(ajaxResponse);
        return ajaxResponse1.setResult(t);
    }

    public  static <T>  AjaxResponse<T> error(){
        return new AjaxResponse<T>(false);
    }
    public  static <T>  AjaxResponse<T> error(ErrorInfo errorInfo){
        return new AjaxResponse<T>(false).setError(errorInfo);
    }
    public  static <T>  AjaxResponse<T> error(Exception ex){
        ErrorInfo errorInfo=new ErrorInfo("500",ex.getMessage());
        errorInfo.setDetails(ex.toString());
        return new AjaxResponse<T>(false).setError(errorInfo);
    }

}
