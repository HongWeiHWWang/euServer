package samsundot.flowablesdk.common;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import samsundot.flowablesdk.common.common.FlowableHelperBase;
import samsundot.flowablesdk.common.common.HttpBuilder;
import samsundot.flowablesdk.common.model.*;
import samsundot.flowablesdk.common.model.flowable.*;
import samsundot.flowablesdk.common.wab.AjaxResponse;
import samsundot.flowablesdk.common.wab.AjaxResponseUtils;
import samsundot.flowablesdk.common.wab.ErrorInfo;

import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class FlowableHelper extends FlowableHelperBase {


    /**
     * @Author jiangwy
     * @Description 引擎信息
     * @Date 2020/4/1 21:14
     **/
    public static String engineInfo() {
        return HttpBuilder.beginRequest("/flowable-rest/service/management/engine")
                .execute(String.class).getBody();
    }

    /**
     * @Author jiangwy
     * @Description 部署流程定义
     * @Date 2020/4/1 21:31
     **/
    public static AjaxResponse<DeploymentProcessOutput> deploymentProcess(String filePath) {
        throw new RuntimeException("未实现");
    }

    /**
     * @Author jiangwy
     * @Description 部署流程定义
     * @Date 2020/4/1 21:33
     **/
    public static AjaxResponse<DeploymentProcessOutput> deploymentProcess(String fileName, byte[] fileContent) {
        throw new RuntimeException("未实现");
    }


    /**
     * @Author jiangwy
     * @Description 启动工作流
     * @Date 2020/4/1 16:35
     **/
    public static AjaxResponse<StartProcessOutput> startProcess(StartProcessInput start) {
        //校验用户
        if (!checkUserExist(start.getOperator()).isSuccess())
        {
            ErrorInfo error=new ErrorInfo("401","Unauthorized");
            return  AjaxResponseUtils.error(error);
        }
        FlowableStartProcessInput flowableStartProcessInput = new FlowableStartProcessInput(start);
        AjaxResponse<FlowableStartProcessOutput> result = HttpBuilder.beginRequest(Constant.START_PROCESS)
                .setToken(getToken(start.getOperator()))
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(flowableStartProcessInput, FlowableStartProcessOutput.class);

        //获取代办
        List<QueryTaskOutput> taskList = null;
        if (start.isReturnTask() && result.getResult() != null) {
            AjaxResponse<List<QueryTaskOutput>> taskResult = queryTasksByProcessId(result.getResult().getId());
            if (taskResult.isSuccess()) taskList = taskResult.getResult();
        }
        //获取流程定义
        AjaxResponse<QueryProcessDefinitionOutput> processDefinitionResult = queryProcessDefinition(result.getResult().getProcessDefinitionId());


        return new AjaxResponse<StartProcessOutput>()
                .setSuccess(result.isSuccess())
                .setError(result.getError())
                .setResult(result.getResult() == null ? null : new StartProcessOutput()
                        .setProcessId(result.getResult().getId())
                        .setProcessDefinitionId(result.getResult().getProcessDefinitionId())
                        .setTaskList(taskList)
                        .setProcessDefinition(processDefinitionResult.getResult())
                );
    }

    /**
     * @Author jiangwy
     * @Description 查询进程
     * @Date 2020/4/1 22:03
     **/
    public static AjaxResponse<QueryProcessOutput> queryProcess(String processId, boolean isReturnTask) {
        String path = String.format("/flowable-rest/service/history/historic-process-instances/%s", processId);
        AjaxResponse<FlowableQueryProcessOutput> result = HttpBuilder.beginRequest(path).executeAjaxResponse(FlowableQueryProcessOutput.class);
        //获取已有代办列表
        List<QueryHistoricTaskOutput> taskList = null;
        if (isReturnTask) {
            AjaxResponse<List<QueryHistoricTaskOutput>> listAjaxResponse = queryHistoricTask(processId);
            if (listAjaxResponse.isSuccess()) taskList = listAjaxResponse.getResult();
        }
        //设置当前节点Key
        String currentActivityKey = "";
        if (result.getResult() != null) {
            //流程结束时间有值代表流程结束
            if (result.getResult().getEndTime() != null) {
                currentActivityKey = "End";
            } else {
                if (CollectionUtils.isNotEmpty(taskList)) {
                    //获取当前代办，代办结束时间无值代表当前代办
                    Optional<QueryHistoricTaskOutput> first = taskList.stream().filter(x -> x.getEndTime() != null).findFirst();
                    if (first.isPresent()) {
                        currentActivityKey = first.get().getKey();
                    }
                }
            }
        }
        //获取流程定义
        AjaxResponse<QueryProcessDefinitionOutput> processDefinitionResult = queryProcessDefinition(result.getResult().getProcessDefinitionId());

        return new AjaxResponse<QueryProcessOutput>(result)
                .setResult(result.getResult() == null ? null : new QueryProcessOutput(result.getResult())
                        .setCurrentActivityKey(currentActivityKey)
                        .setHistoricTaskList(taskList)
                        .setProcessDefinition(processDefinitionResult.getResult())
                );
    }

    /**
     * 终止流程
     *
     * @param processId
     * @param reason
     * @return
     */
    public static AjaxResponse<QueryProcessOutput> abortProcess(String operatorUserName,String processId, String reason) {
        //获取所有当前流程代办
        AjaxResponse<List<QueryTaskOutput>> tasks = queryTasksByProcessId(processId);
        if (CollectionUtils.isNotEmpty(tasks.getResult())) {
            //根据操作人，匹配一下对应的代办
            Optional<QueryTaskOutput> queryTaskOutput = tasks.getResult().stream().filter(x -> x.getUserName().toLowerCase() == operatorUserName.toLowerCase()).findFirst();
            //如果没有找到对应代办，则使用第一个代办代替
            QueryTaskOutput task=null;

            if (queryTaskOutput.isPresent()){
                task=queryTaskOutput.get();
            }else{
                task = tasks.getResult().get(0);
            }

            //插入一个代办原因
            insertTaskComment(getADMIN_NAME(),task.getTaskId(), reason);
            String path = String.format("/%s/%s/change-state", Constant.ABORT_PROCESS, processId);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("cancelActivityIds", tasks.getResult().stream().map(c -> c.getKey()));
            jsonObject.put("startActivityIds", new String[]{"End"});
            AjaxResponse<Object> result = HttpBuilder.beginRequest(path).setMethod(HttpMethod.POST)
                    .executeAjaxResponse(jsonObject);

            //获取流程实例（不需要返回历史代办）
            AjaxResponse<QueryProcessOutput> processResult = queryProcess(processId, false);

            //把终止流程前的当前代办数据整理并返回（去除当前终止人代办）
            processResult.getResult().setHistoricTaskList(tasks.getResult().stream()
                    .filter(x -> x.getUserName().toLowerCase()!= operatorUserName.toLowerCase())
                    .map(x->new QueryHistoricTaskOutput()
                            .setTaskId(x.getTaskId())
                            .setKey(x.getKey())
                            .setName(x.getName())
                            .setUserName(x.getUserName())
                            .setStartTime(x.getCreateTime())
                            .setEndTime(new Date())
                    ).collect(Collectors.toList()));


            return new AjaxResponse<QueryProcessOutput>(result).setResult(processResult.getResult());
        }
        return AjaxResponseUtils.error(new ErrorInfo("404","Not Found Tasks"));
    }

    /// <summary>
    /// 删除流程
    /// </summary>
    /// <param name="processId"></param>
    /// <param name="reason"></param>
    /// <returns></returns>
    public static AjaxResponse<Boolean> deleteProcess(String processId, String reason) {
        AjaxResponse<Object> result = HttpBuilder.beginRequest("/flowable-rest/service/runtime/process-instances/" + processId + "?deleteReason=" + reason)
                .setMethod(HttpMethod.DELETE)
                .executeAjaxResponse();

        return AjaxResponseUtils.result(result);
    }

    /// <summary>
    /// 流程节点跳转
    /// </summary>
    /// <param name="processId">流程Id</param>
    /// <param name="currentActivityKey">当前节点Key</param>
    /// <param name="targetActivityKey">目标节点Key</param>
    /// <param name="reason">原因</param>
    /// <returns></returns>
    public static AjaxResponse<Boolean> processActivityJump(String processId, String currentActivityKey, String targetActivityKey, String reason) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cancelActivityIds", new String[]{currentActivityKey});
        jsonObject.put("startActivityIds", new String[]{targetActivityKey});
        AjaxResponse<Object> result = HttpBuilder.beginRequest("/flowable-rest/service/runtime/process-instances/" + processId + "/change-state")
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(jsonObject);
        return AjaxResponseUtils.success();
    }

    /// <summary>
    /// 查询代办(支持：用户名、流程Key、分页)
    /// </summary>
    /// <param name="query"></param>
    public static AjaxResponse<QueryTaskPagedOutput> queryTasksPaged(QueryTaskPagedInput query) {
        //查询代办，用户名和流程Key没有值，必须置为null
        return HttpBuilder.beginRequest("/flowable-rest/service/query/tasks")
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(new FlowableQueryTaskPagedInput()
                                .setStart((query.getPageIndex() - 1) * query.getPageSize())
                                .setSize(query.getPageSize())
                                .setAssignee(StringUtils.isEmpty(query.getUserName()) ? null : query.getUserName())
                                .setProcessDefinitionKey(StringUtils.isEmpty(query.getProcessKey()) ? null : query.getProcessKey())
                        , FlowableQueryTaskOutput.class
                        , c -> {
                            return (c == null || c.getTotal() == 0) ? null : new QueryTaskPagedOutput()
                                    .setTotal(c.getTotal())
                                    .setData(c.getData().stream().map(k -> new QueryTaskOutput(k)).collect(Collectors.toList()));
                        });
    }

    /// <summary>
    /// 根据用户名，查询代办
    /// </summary>
    /// <param name="userName">用户名（ITCode）</param>
    /// <returns></returns>
    public static AjaxResponse<List<QueryTaskOutput>> queryTasksByUserName(String userName) {
        return queryTasks(null, null, userName);
    }

    /**
     * @Author jiangwy
     * @Description 根据流程Id，查询代办
     * @Date 2020/4/1 16:34
     **/
    public static AjaxResponse<List<QueryTaskOutput>> queryTasksByProcessId(String processId) {
        return queryTasks(processId, null, null);
    }

    /**
     * @Author jiangwy
     * @Description 根据流程Id，查询代办
     * @Date 2020/4/1 16:34
     **/
    public static AjaxResponse<List<QueryTaskOutput>> queryTasksByProcessKey(String processKey) {
        return queryTasks(null, processKey, null);
    }

    /// <summary>
    /// 审批
    /// </summary>
    /// <param name="approve"></param>
    /// <returns></returns>
    public static AjaxResponse<ApproveOutput> approve(ApproveInput approve) {
        //校验用户
        if (!checkUserExist(approve.getOperator()).isSuccess())
        {
            ErrorInfo error=new ErrorInfo("401","Unauthorized");
            return  AjaxResponseUtils.error(error);
        }
        if (approve.getVariables() == null) {
            approve.setVariables(new ArrayList<>());
        }
        List<FlowableProcessVariable> variableList = approve.getVariables().stream()
                .map(c -> new FlowableProcessVariable(c)).collect(Collectors.toList());
        variableList.add(new FlowableProcessVariable("_IsApproved", true));
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("action", "complete");
        jsonObject.put("variables", variableList);

        //插入代办评论
        insertTaskComment(approve.getOperator(),approve.getTaskId(), approve.getReason());

        String url = String.format("%s/%s", Constant.APPROVE, approve.getTaskId());
        AjaxResponse<Object> result = HttpBuilder.beginRequest(url)
                .setToken(getToken(approve.getOperator()))
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(jsonObject, Object.class);
        //获取代办
        List<QueryTaskOutput> taskList = null;
        if (approve.isReturnTask() && result.isSuccess()) {
            AjaxResponse<List<QueryTaskOutput>> taskResult = queryTasksByProcessId(approve.getProcessId());
            if (taskResult.isSuccess()) taskList = taskResult.getResult();
        }
        //获取流程实例（不需要返回历史代办）
        AjaxResponse<QueryProcessOutput> processResult = queryProcess(approve.getProcessId(), false);
        return AjaxResponseUtils.result(result, result.isSuccess() ? new ApproveOutput()
                .setProcessId(approve.getProcessId())
                .setBusinessId((processResult.isSuccess() && processResult.getResult() != null) ? processResult.getResult().getBusinessId() : null)
                .setProcessName((processResult.isSuccess() && processResult.getResult() != null) ? processResult.getResult().getProcessName() : null)
                .setStartTime((processResult.isSuccess() && processResult.getResult() != null) ? processResult.getResult().getStartTime() : null)
                .setEndTime((processResult.isSuccess() && processResult.getResult() != null) ? processResult.getResult().getEndTime() : null)
                .setStartUserName((processResult.isSuccess()&&processResult.getResult()!=null)?processResult.getResult().getStartUserName():null)
                .setTaskList(taskList)
                .setProcessDefinition((processResult.isSuccess() && processResult.getResult() != null) ? processResult.getResult().getProcessDefinition():null)
                : null);
    }

    /// <summary>
    /// 插入代办评论
    /// </summary>
    /// <param name="operatorUserName"></param>
    /// <param name="taskId"></param>
    /// <param name="comment"></param>
    /// <returns></returns>
    public static AjaxResponse<Boolean> insertTaskComment(String operatorUserName, String taskId, String comment) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("message", comment);
        jsonObject.put("saveProcessInstanceId", true);
        return HttpBuilder.beginRequest("/flowable-rest/service/runtime/tasks/" + taskId + "/comments")
                .setToken(operatorUserName.equals(getADMIN_NAME())?getTOKEN():getToken(operatorUserName))
                .setMethod(HttpMethod.POST)
                .putAjaxResponse(jsonObject, c -> true);
    }

    /// <summary>
    /// 查询代办评论
    /// </summary>
    /// <param name="processId"></param>
    public static AjaxResponse<List<QueryTaskCommentOutput>> queryTaskComment(String processId) {
        return HttpBuilder.beginRequest("/flowable-rest/service/history/historic-process-instances/" + processId + "/comments")
                .getAjaxResponse(FlowableQueryTaskCommentOutput[].class, c -> {
                            List<QueryTaskCommentOutput> resultList = new ArrayList<QueryTaskCommentOutput>();
                            if (c != null && c.length > 0) {
                                List<FlowableQueryTaskCommentOutput> list = Arrays.asList(c);
                                resultList = list.stream().sorted(Comparator.comparing(FlowableQueryTaskCommentOutput::getTime))
                                        .map(k -> new QueryTaskCommentOutput(k)).collect(Collectors.toList());
                            }
                            return resultList;
                        }
                );
    }


    /// <summary>
    /// 查询历史代办
    /// </summary>
    /// <param name="processId"></param>
    /// <returns></returns>
    public static AjaxResponse<List<QueryHistoricTaskOutput>> queryHistoricTask(String processId) {
        AjaxResponse<FlowableQueryHistoricTaskOutput> result = HttpBuilder.beginRequest("/flowable-rest/service/history/historic-task-instances?processInstanceId=" + processId)

                .executeAjaxResponse(FlowableQueryHistoricTaskOutput.class);

        if (result.isSuccess() && result.getResult() != null && CollectionUtils.isNotEmpty(result.getResult().getData())) {
            //清理未处理，但是已经存的代办，比如多人审批节点，一人审批即结束，其他人代办自动完结。
            //"MI_END" 多人审批 一人通过 其他代办自动删除代办
            //"Change parent activity to End" 终止流程 删除代办
            List<FlowableQueryHistoricTaskDataOutput> list = result.getResult().getData().stream().filter(c ->
                    !"MI_END".equals(c.getDeleteReason())
                            && !"Change parent activity to End".equals(c.getDeleteReason()))
                    //按代办开始时间排序
                    .sorted(Comparator.comparing(FlowableQueryHistoricTaskDataOutput::getStartTime))
                    .collect(Collectors.toList());
            //获取代办评论
            AjaxResponse<List<QueryTaskCommentOutput>> taskCommentList = queryTaskComment(processId);
            if (taskCommentList.isSuccess() && CollectionUtils.isNotEmpty(taskCommentList.getResult())) {
                for (FlowableQueryHistoricTaskDataOutput taskData : list) {
                    List<QueryTaskCommentOutput> commentList = taskCommentList.getResult().stream().filter(x -> x.getTaskId().equals(taskData.getId())).collect(Collectors.toList());
                    taskData.setCommentList(commentList);
                }
            }
            result.getResult().setData(list);
        }
        return AjaxResponseUtils.result(result,
                (result.getResult() != null && result.getResult().getData() != null) ?
                        result.getResult().getData().stream().map(x -> new QueryHistoricTaskOutput(x)).collect(Collectors.toList()) : null
        );
    }

    /**
     * @Author jiangwy
     * @Description 插入Task
     * @Date 2020/4/2 0:19
     **/
    public static AjaxResponse<List<QueryTaskOutput>> queryTasks(String processId, String processKey, String userName) {
        JSONObject jsonObject = new JSONObject();
        if (!org.springframework.util.StringUtils.isEmpty(processId)) {
            jsonObject.put("processInstanceId", processId);
        }
        if (!org.springframework.util.StringUtils.isEmpty(processKey)) {
            jsonObject.put("processDefinitionKey", processKey);
        }
        if (!org.springframework.util.StringUtils.isEmpty(userName)) {
            jsonObject.put("assignee", userName);
        }
        return HttpBuilder.beginRequest(Constant.QUERY_TASKS)
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(jsonObject, FlowableQueryTaskOutput.class,
                        c -> {
                            List<QueryTaskOutput> queryTaskOutputList = new ArrayList<>();
                            if (c != null && CollectionUtils.isNotEmpty(c.getData())) {
                                queryTaskOutputList = c.getData().stream()
                                        .map(k -> new QueryTaskOutput(k)).collect(Collectors.toList());
                            }
                            return queryTaskOutputList;
                        });
    }

    /**
     * @Author jiangwy
     * @Description 查询已办(支持：用户名、流程Key、分页)
     * @Date 2020/4/2 10:20
     **/
    public static AjaxResponse<QueryFinishedTaskPagedOutput> queryFinishedTasksPaged(QueryFinishedTaskPagedInput query) {
        FlowableQueryFinishedTaskPagedInput result=new FlowableQueryFinishedTaskPagedInput()
                .setStart((query.getPageIndex() - 1) * query.getPageSize())
                .setSize(query.getPageSize())
                .setTaskAssignee(StringUtils.isEmpty(query.getUserName()) ? null : query.getUserName())
                .setProcessDefinitionKey(StringUtils.isEmpty(query.getProcessKey()) ? null : query.getProcessKey());

        //查询已办，用户名和流程Key没有值，必须置为null
        return HttpBuilder.beginRequest("/flowable-rest/service/query/historic-task-instances")
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(new FlowableQueryFinishedTaskPagedInput()
                                .setStart((query.getPageIndex() - 1) * query.getPageSize())
                                .setSize(query.getPageSize())
                                .setTaskAssignee(StringUtils.isEmpty(query.getUserName()) ? null : query.getUserName())
                                .setProcessDefinitionKey(StringUtils.isEmpty(query.getProcessKey()) ? null : query.getProcessKey()),
                        FlowableQueryFinishedTaskOutput.class,
                        c -> {
                            QueryFinishedTaskPagedOutput queryFinishedTaskPagedOutput = null;
                            if (c != null) {
                                queryFinishedTaskPagedOutput = new QueryFinishedTaskPagedOutput()
                                        .setTotal(c.getTotal())
                                        .setData(CollectionUtils.isNotEmpty(c.getData()) ? c.getData().stream().map(k ->
                                                new QueryFinishedTaskOutput()
                                                        .setTaskId(k.getId())
                                                        .setUserName(k.getAssignee())
                                                        .setProcessId(k.getProcessInstanceId())
                                                        .setName(k.getName())
                                                        .setKey(k.getTaskDefinitionKey())
                                                        .setStartTime(k.getStartTime())
                                                        .setEndTime(k.getEndTime())).collect(Collectors.toList())
                                                : null);
                            }
                            return queryFinishedTaskPagedOutput;
                        });
    }


    /**
     * 批量审批
     * @param approveList
     * @return
     */
    public static AjaxResponse<List<AjaxResponse<ApproveOutput>>> batchApprove(List<ApproveInput> approveList)
    {
        List<AjaxResponse<ApproveOutput>> resultList = new ArrayList<>();
        for (ApproveInput item : approveList) {
            try
            {
                AjaxResponse<ApproveOutput> approve = approve(item);
                resultList.add(approve);
            }
            catch (Exception ex)
            {
                resultList.add(AjaxResponseUtils.error(ex));
            }
        }
        return new AjaxResponse<List<AjaxResponse<ApproveOutput>>>(true,resultList);
    }

    /**
     * @Author jiangwy
     * @Description 批量终止流程
     * @Date  2020/4/6 21:59
     **/
    public static AjaxResponse<List<AjaxResponse<QueryProcessOutput>>> batchAbortProcess(String operatorUserName,String[] processIds, String reason)
    {
        List<AjaxResponse<QueryProcessOutput>> result = new ArrayList<>();

        if (processIds!=null&&processIds.length>0){
            for (String processId : processIds) {
                try{
                    AjaxResponse<QueryProcessOutput> booleanAjaxResponse = abortProcess(operatorUserName,processId, reason);
                    //把具体的流程Id返回去
                    result.add(booleanAjaxResponse);
                }catch (Exception ex){
                    result.add(new AjaxResponse<QueryProcessOutput>(false,new QueryProcessOutput().setProcessId(processId)));
                }

            }
        }
        return AjaxResponseUtils.success(result);
    }


    /// <summary>
    /// 查询流程定义
    /// </summary>
    /// <param name="processDefinitionId"></param>
    /// <returns></returns>
    public static AjaxResponse<QueryProcessDefinitionOutput> queryProcessDefinition(String processDefinitionId) {
        String path = "";
        try {
            path = "/flowable-rest/service/repository/process-definitions/" +  processDefinitionId   + "/model";
        } catch (Exception ex) {
        }

        return HttpBuilder.beginRequest(path)
                .setMethod(HttpMethod.GET)
                .getAjaxResponse(FlowableQueryProcessDefinitionOutput.class, c -> {
                    if (c != null && c.getProcesses() != null) {
                        return new QueryProcessDefinitionOutput()
                                .setProcessKey(c.getProcesses().get(0).getId())
                                .setProcessName(c.getProcesses().get(0).getName())
                                .setDataObjectList(c.getProcesses().get(0).getDataObjects().stream()
                                        .map(x -> new QueryProcessDefinitionDataObject()
                                                .setId(x.getId())
                                                .setName(x.getName())
                                                .setValue(x.getValue())
                                                .setType(x.getType())).collect(Collectors.toList()))
                                .setFlowElementList(c.getProcesses().get(0).getFlowElementMap().entrySet().stream()
                                        .filter(x -> x.getValue().getIncomingFlows() != null || x.getValue().getOutgoingFlows() != null)
                                        .map(x -> new QueryProcessDefinitionFlowElement()
                                                .setKey(x.getValue().getId())
                                                .setName(x.getValue().getName())
                                                .setAssignee(x.getValue().getAssignee())
                                                .setAttributeList(x.getValue().getAttributes() == null || x.getValue().getAttributes().size() == 0 ? null
                                                        : x.getValue().getAttributes().values().stream().map(k -> new QueryProcessDefinitionAttribute(k.get(0).getName(), k.get(0).getValue())).collect(Collectors.toList()))
                                                .setIncomingFlowList(x.getValue().getIncomingFlows() == null || x.getValue().getIncomingFlows().size() == 0 ? null
                                                        : x.getValue().getIncomingFlows().stream().map(k -> new QueryProcessDefinitionInOutFlow()
                                                                .setKey(k.getId())
                                                                .setName(k.getName())
                                                                .setConditionExpression(k.getConditionExpression())
                                                                .setSourceKey(k.getSourceRef())
                                                                .setTargetKey(k.getTargetRef())
                                                        ).collect(Collectors.toList())
                                                )
                                                .setOutgoingFlowList(x.getValue().getOutgoingFlows() == null || x.getValue().getOutgoingFlows().size() == 0 ? null
                                                        : x.getValue().getOutgoingFlows().stream().map(k -> new QueryProcessDefinitionInOutFlow()
                                                        .setKey(k.getId())
                                                        .setName(k.getName())
                                                        .setConditionExpression(k.getConditionExpression())
                                                        .setSourceKey(k.getSourceRef())
                                                        .setTargetKey(k.getTargetRef())
                                                ).collect(Collectors.toList()))
                                                .setLoopCharacteristic(x.getValue().getLoopCharacteristics() == null ? null : new QueryProcessDefinitionLoopCharacteristic()
                                                        .setListVariable(x.getValue().getLoopCharacteristics().getInputDataItem())
                                                        .setElementVariable(x.getValue().getLoopCharacteristics().getElementVariable())
                                                        .setCompletionCondition(x.getValue().getLoopCharacteristics().getCompletionCondition())
                                                        .setIsSequential(x.getValue().getLoopCharacteristics().getSequential()))
                                        ).collect(Collectors.toList()));


                    } else {
                        return null;
                    }
                });
    }

    /// <summary>
    /// 查询最新的流程定义
    /// </summary>
    /// <param name="processKey"></param>
    /// <returns></returns>
    public static AjaxResponse<QueryProcessDefinitionOutput> queryLatestProcessDefinition(String processKey)
    {
        //查询流程定义列表（最近更新的）
        String path="/flowable-rest/service/repository/process-definitions?key=" + processKey + "&latest=true";
        AjaxResponse<FlowableQueryProcessDefinitionListOutput> processDefinitionResult = HttpBuilder.beginRequest(path)
                .setMethod(HttpMethod.GET)
                .executeAjaxResponse(FlowableQueryProcessDefinitionListOutput.class);
        if (processDefinitionResult.getResult() != null && processDefinitionResult.getResult().getData() != null && processDefinitionResult.getResult().getData().size() > 0)
        {
            return queryProcessDefinition(processDefinitionResult.getResult().getData().get(0).getId());
        }
        return new AjaxResponse<QueryProcessDefinitionOutput>(true);
    }

    /// <summary>
    /// 查询用户
    /// </summary>
    /// <param name="userName"></param>
    /// <returns></returns>
    public static AjaxResponse<QueryUserOutput> queryUser(String userName)
    {
        //用户名统一小写
        userName = userName.toLowerCase();
        String path=String.format("/flowable-rest/service/identity/users/%s" , userName);
        return HttpBuilder.beginRequest(path)
                .setMethod(HttpMethod.GET)
                .getAjaxResponse(FlowableQueryUserOutput.class,c->new QueryUserOutput(c.getId(),c.getEmail()));
    }

    /// <summary>
    /// 创建用户
    /// </summary>
    /// <param name="userName"></param>
    /// <returns></returns>
    public static AjaxResponse<Boolean> createUser(String userName)
    {
        //用户名统一小写
        userName = userName.toLowerCase();
        FlowableCreateUserInput flowableCreateUserInput = new FlowableCreateUserInput(userName, userName, String.format("%s%s", userName, DEFAULT_EMAIL_SUFFIX), DEFAULT_USER_PASSWORD);

        //创建用户
        AjaxResponse<FlowableQueryUserOutput> flowableQueryUserOutputAjaxResponse = HttpBuilder.beginRequest("/flowable-rest/service/identity/users")
                .setMethod(HttpMethod.POST)
                .executeAjaxResponse(flowableCreateUserInput, FlowableQueryUserOutput.class);

        return AjaxResponseUtils.result(flowableQueryUserOutputAjaxResponse,flowableQueryUserOutputAjaxResponse.isSuccess());

    }
    /// <summary>
    /// 校验用户是否存在
    /// </summary>
    /// <param name="userName"></param>
    /// <returns></returns>
    public static AjaxResponse<Boolean> checkUserExist(String userName)
    {
        AjaxResponse<QueryUserOutput> result = queryUser(userName);

        //授权系统自动创建用户
        if (!result.isSuccess() && Boolean.parseBoolean(IS_AUTO_CREATE_USER))
        {
            AjaxResponse<Boolean> createUserResult = createUser(userName);
            return createUserResult;
        }
        return AjaxResponseUtils.result(result,result.isSuccess());
    }
}
