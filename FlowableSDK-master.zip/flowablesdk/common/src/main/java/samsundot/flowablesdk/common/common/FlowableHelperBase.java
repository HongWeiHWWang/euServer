package samsundot.flowablesdk.common.common;

import com.alibaba.fastjson.JSONObject;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.nio.charset.Charset;

public abstract class FlowableHelperBase {
    static{
        restTemplate=  new RestTemplate(new SimpleClientHttpRequestFactory());
    }
    @Value("${flowable.base_url}")
    private String _BASE_URL;
    @Value("${flowable.admin_name}")
    private String _ADMIN_NAME;
    @Value("${flowable.admin_password}")
    private String _ADMIN_PASSWORD;
    @Value("${flowable.debug:'false'}")
    private String _DEBUG;
    @Value("${flowable.is_auto_create_user}")
    private String _IS_AUTO_CREATE_USER;
    @Value("${flowable.default_user_password}")
    private String _DEFAULT_USER_PASSWORD;
    @Value("${flowable.default_email_suffix}")
    private String _DEFAULT_EMAIL_SUFFIX;

    /**
     *Flowable是否自动创建用户
     * @param
     * @author jiangwy
     * @return
     */
    protected static String IS_AUTO_CREATE_USER="";

    /// <summary>
    /// Flowable默认用户密码
    /// </summary>
    protected static String DEFAULT_USER_PASSWORD="";

    /// <summary>
    /// Flowable默认邮箱后缀
    /// </summary>
    protected static String DEFAULT_EMAIL_SUFFIX="";


    protected static RestTemplate restTemplate;
    /// Flowable根地址Url
    /// <summary>
    /// </summary>
    private static String BASE_URL = "";

    public static String getBaseUrl(){
        return BASE_URL;
    }
    public static String getTOKEN(){return TOKEN;}
    public static String getADMIN_NAME(){return ADMIN_NAME;}
    /// <summary>
    /// Flowable管理员账号
    /// </summary>
    private static String ADMIN_NAME ="";

    /// <summary>
    /// Flowable管理员密码
    /// </summary>
    private static String ADMIN_PASSWORD = "";

    private static String DEBUG="";

    private static String TOKEN="";

    @PostConstruct
    private void init() {
//        this.restTemplate=_restTemplate;
        BASE_URL=_BASE_URL;
        ADMIN_NAME=_ADMIN_NAME;
        ADMIN_PASSWORD=_ADMIN_PASSWORD;
        DEBUG=_DEBUG;
        DEFAULT_EMAIL_SUFFIX=_DEFAULT_EMAIL_SUFFIX;
        IS_AUTO_CREATE_USER=_IS_AUTO_CREATE_USER;
        DEFAULT_USER_PASSWORD=_DEFAULT_USER_PASSWORD;
        TOKEN =getToken(ADMIN_NAME,ADMIN_PASSWORD);
    }
    /**
     * 获取token
     * @author jiangwy
     * @return java.lang.String
     */
    public static String getToken(String name){
        return getToken(name,DEFAULT_USER_PASSWORD);
    }
    /**
     * 获取token
     * @author jiangwy
     * @return java.lang.String
     */
    public static String getToken(String name,String password){
        String sourceString = String.format("%s:%s", name, password);
        //将字符串转base64字符串
        byte[] encodedAuth= Base64.encodeBase64((sourceString.getBytes(Charset.forName("UTF-8"))));
        return String.format("Basic %s",new String(encodedAuth));
    }

    /**
     * @Author jiangwy
     * @Description 交换请求
     * @Date  2020/4/1 17:29
     **/
    public static <T,R> ResponseEntity<T> exchange(String url,HttpMethod method,R request,Class<T> responseType){
         return exchange(url,method,request,responseType,TOKEN);
    }
    /**
     * @Author jiangwy
     * @Description 交换请求
     * @Date  2020/4/1 17:29
     **/
    public static <T,R> ResponseEntity<T> exchange(String url,HttpMethod method,R request,Class<T> responseType,String token){
        if (!StringUtils.isEmpty(DEBUG)&&"true".equals(DEBUG)){
            if (request!=null) {
                System.out.println(JSONObject.toJSONString(request));
            }else{
                System.out.println("参数为null");
            }
        }
        return restTemplate.exchange(url,method, getHttpEntity(request,token), responseType);
    }
    /**
     * @Author jiangwy
     * @Description 构建Http实体参数，添加Token
     * @Date  2020/4/1 16:34
     **/
    public static <T> HttpEntity<T> getHttpEntity(T entity){
        return getHttpEntity(entity,TOKEN);
    }
    /**
     * @Author jiangwy
     * @Description 构建Http实体参数，添加Token
     * @Date  2020/4/1 16:34
     **/
    public static <T> HttpEntity<T> getHttpEntity(T entity,String token){
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization",token);
        return new HttpEntity<T>(entity, headers);
    }
}
