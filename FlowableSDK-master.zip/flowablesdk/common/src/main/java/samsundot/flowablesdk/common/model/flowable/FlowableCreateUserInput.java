package samsundot.flowablesdk.common.model.flowable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 描述：
 *
 * @ClassName FlowableCreateUserOutput
 * @Author jiangwy
 * @Date 2020/5/6 16:24
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlowableCreateUserInput {
   private String  id;
    private String lastName ;
    private String  email ;
    private String password;
}
