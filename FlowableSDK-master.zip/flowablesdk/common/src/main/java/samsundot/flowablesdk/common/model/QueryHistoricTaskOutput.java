package samsundot.flowablesdk.common.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import samsundot.flowablesdk.common.model.flowable.FlowableQueryHistoricTaskDataOutput;

import java.util.Date;
import java.util.List;

@NoArgsConstructor
@Accessors(chain = true)
@Data
public class QueryHistoricTaskOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String taskId;

    /// <summary>
    /// 流程节点名
    /// </summary>
    private String name;

    /// <summary>
    /// 流程节点Key
    /// </summary>
    private String key;

    /// <summary>
    /// 代办人
    /// </summary>
    private String userName;

    /// <summary>
    /// 代办开始时间
    /// </summary>
    private Date startTime;

    /// <summary>
    /// 代办结束时间
    /// </summary>
    private Date endTime;

    /// <summary>
    /// 评论
    /// </summary>
    private List<QueryTaskCommentOutput> commentList;

    public QueryHistoricTaskOutput(FlowableQueryHistoricTaskDataOutput taskData) {
        this.taskId = taskData.getId();
        this.name = taskData.getName();
        this.key = taskData.getTaskDefinitionKey();
        this.userName = taskData.getAssignee();
        this.startTime = taskData.getStartTime();
        this.endTime = taskData.getEndTime();
        this.commentList = taskData.getCommentList();
    }
}
