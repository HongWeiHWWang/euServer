package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ProcessVariable {
    /**
     * 变量名称
     */
    private String name;

    /// <summary>
    /// 变量值(字符串、数字、数组等)
    /// </summary>
    private Object value;
}
