package samsundot.flowablesdk.common.model.flowable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import samsundot.flowablesdk.common.model.StartProcessInput;

import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class FlowableStartProcessInput {
    private String processDefinitionKey;
    private String businessKey;
    private List<FlowableProcessVariable> variables;

    public FlowableStartProcessInput(StartProcessInput start) {
        if (start!=null) {
            this.processDefinitionKey = start.getProcessKey();
            this.businessKey=start.getBusinessId();
            if (CollectionUtils.isNotEmpty(start.getVariables())) {
                this.variables=start.getVariables().stream()
                        .map(c->new FlowableProcessVariable(c))
                        .collect(Collectors.toList());
            }
        }
    }
}
