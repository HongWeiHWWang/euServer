package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionListOutput
 * @Author jiangwy
 * @Date 2020/5/7 1:10
 **/
@Data
public class FlowableQueryProcessDefinitionListOutput {
    private List<FlowableQueryProcessDefinitionBaseInfoOutput> data;

    private int total;
}
