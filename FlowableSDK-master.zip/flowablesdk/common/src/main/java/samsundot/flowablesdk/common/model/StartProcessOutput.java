package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@Data
public class StartProcessOutput {
    //工作流id
    private String processId;

    /// <summary>
    /// 流程定义Id
    /// </summary>
    public String processDefinitionId;


    private List<QueryTaskOutput> taskList;

    /// <summary>
    /// 流程定义
    /// </summary>
    public QueryProcessDefinitionOutput processDefinition;
}
