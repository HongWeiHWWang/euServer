package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.List;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionOutput
 * @Author jiangwy
 * @Date 2020/5/7 0:12
 **/
@Data
public class FlowableQueryProcessDefinitionOutput {
    private List<FlowableQueryProcessDefinitionProcess> processes;
}
