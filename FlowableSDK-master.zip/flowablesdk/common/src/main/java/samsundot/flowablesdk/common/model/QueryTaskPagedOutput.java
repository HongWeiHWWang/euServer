package samsundot.flowablesdk.common.model;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Author jiangwy
 * @Description 分页任务结果
 * @Date  2020/4/1 23:52
 **/
@Accessors(chain = true)
@Data
public class QueryTaskPagedOutput {
    private int total;
    private List<QueryTaskOutput> data;
}
