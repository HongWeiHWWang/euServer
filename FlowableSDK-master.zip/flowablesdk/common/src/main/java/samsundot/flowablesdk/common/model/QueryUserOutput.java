package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 描述：
 *
 * @ClassName QueryUserOutput
 * @Author jiangwy
 * @Date 2020/5/6 16:12
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryUserOutput {
    private String userName;

    private String email;
}
