package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.List;

@Data
public class FlowableQueryFinishedTaskOutput {
    /// <summary>
    /// 代办数据集合
    /// </summary>
    private List<FlowableQueryFinishedTaskDataOutput> data ;

    /// <summary>
    /// 代办数量
    /// </summary>
    private int total ;
}
