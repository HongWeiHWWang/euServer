package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

import java.util.Date;

@Data
public class FlowableQueryFinishedTaskDataOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String id ;

    /// <summary>
    /// 代办人（用户名）
    /// </summary>
    private String assignee ;

    /// <summary>
    /// 流程Id
    /// </summary>
    private String processInstanceId ;

    /// <summary>
    /// 流程节点名
    /// </summary>
    private String name ;

    /// <summary>
    /// 流程节点Key
    /// </summary>
    private String taskDefinitionKey ;

    /// <summary>
    /// 代办开始时间
    /// </summary>
    private Date startTime ;

    /// <summary>
    /// 代办结束时间
    /// </summary>
    private Date  endTime ;

    /// <summary>
    /// 代办删除原因
    /// </summary>
    private String deleteReason ;
}
