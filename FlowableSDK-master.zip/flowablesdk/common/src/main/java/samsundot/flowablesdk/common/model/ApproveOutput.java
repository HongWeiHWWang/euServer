package samsundot.flowablesdk.common.model;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

@Accessors(chain = true)
@Data
public class ApproveOutput {
    /// <summary>
    /// 流程实例Id
    /// </summary>
    private String processId ;

    /// <summary>
    /// 业务Id
    /// </summary>
    private String businessId ;

    /// <summary>
    /// 流程名称
    /// </summary>
    private String processName ;

    /// <summary>
    /// 开始时间
    /// </summary>
    private Date startTime ;

    /// <summary>
    /// 结束时间
    /// </summary>
    private Date endTime ;
    /// <summary>
    /// 流程创建人
    /// </summary>
    private String startUserName;

    /// <summary>
    /// 代办列表
    /// </summary>
    private List<QueryTaskOutput> taskList ;

    /// <summary>
    /// 流程定义
    /// </summary>
    private QueryProcessDefinitionOutput processDefinition;

}
