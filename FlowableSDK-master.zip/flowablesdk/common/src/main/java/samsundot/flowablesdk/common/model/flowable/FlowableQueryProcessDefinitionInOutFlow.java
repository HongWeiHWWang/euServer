package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;

/**
 * 描述：
 *
 * @ClassName FlowableQueryProcessDefinitionInOutFlow
 * @Author jiangwy
 * @Date 2020/5/7 0:19
 **/
@Data
public class FlowableQueryProcessDefinitionInOutFlow {
    private String id ;

    private String name ;

    private String conditionExpression ;

    private String sourceRef ;

    private String targetRef ;
}
