package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;
import samsundot.flowablesdk.common.model.QueryTaskOutput;

import java.util.List;

@Data
public class FlowableStartProcessOutput {
    /**
     * 流程实例Id
     */
    private String id;
//    /**
//     * 代办列表
//     */
//    private List<QueryTaskOutput> taskList;
    private String processDefinitionId;
}
