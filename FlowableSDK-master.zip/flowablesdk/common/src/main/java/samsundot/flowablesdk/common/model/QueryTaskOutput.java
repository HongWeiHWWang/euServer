package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import samsundot.flowablesdk.common.model.flowable.FlowableQueryTaskDataOutput;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class QueryTaskOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    private String taskId;

    /**
     * 审核人
     */
    private String userName;

    /// <summary>
    /// 流程Id
    /// </summary>
    private String processId ;

    /// <summary>
    /// 当前代办的流程节点名
    /// </summary>
    private String name;
    /// <summary>
    /// 流程节点Key
    /// </summary>
    private String key;

    /// <summary>
    /// 流程定义Id
    /// </summary>
    public String processDefinitionId;
    /**
     * 创建时间
     */
    private Date createTime;



    public QueryTaskOutput(FlowableQueryTaskDataOutput flowableQueryTaskDataOutput) {
        this.taskId = flowableQueryTaskDataOutput.getId();
        this.userName=flowableQueryTaskDataOutput.getAssignee();
        this.processId=flowableQueryTaskDataOutput.getProcessInstanceId();
        this.name=flowableQueryTaskDataOutput.getName();
        this.key=flowableQueryTaskDataOutput.getTaskDefinitionKey();
        this.processDefinitionId=flowableQueryTaskDataOutput.getProcessDefinitionId();
        this.createTime=flowableQueryTaskDataOutput.getCreateTime();
    }
}
