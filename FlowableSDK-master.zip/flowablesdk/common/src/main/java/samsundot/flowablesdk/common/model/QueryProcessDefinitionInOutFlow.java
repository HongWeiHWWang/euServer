package samsundot.flowablesdk.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * 描述：
 *
 * @ClassName QueryProcessDefinitionInOutFlow
 * @Author jiangwy
 * @Date 2020/5/6 23:49
 **/
@Accessors(chain = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProcessDefinitionInOutFlow {
    /// <summary>
    /// 流程线Key
    /// </summary>
    private String key ;

    /// <summary>
    /// 流程线名称
    /// </summary>
    private String name ;

    /// <summary>
    /// 条件表达式
    /// </summary>
    private String conditionExpression ;

    /// <summary>
    /// 来源Key
    /// </summary>
    private String sourceKey ;

    /// <summary>
    /// 目标Key
    /// </summary>
    private String targetKey ;
}
