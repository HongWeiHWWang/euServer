package samsundot.flowablesdk.common.model;

import lombok.Data;
import samsundot.flowablesdk.common.model.flowable.FlowableQueryTaskCommentOutput;

import java.util.Date;

@Data
public class QueryTaskCommentOutput {
    /// <summary>
    /// 代办Id
    /// </summary>
    public String taskId;

    /// <summary>
    /// 评论
    /// </summary>
    public String comment;

    /// <summary>
    /// 时间
    /// </summary>
    public Date time;

    public QueryTaskCommentOutput(FlowableQueryTaskCommentOutput flowableQueryTaskCommentOutput) {
        this.taskId = flowableQueryTaskCommentOutput.getTaskId();
        this.comment = flowableQueryTaskCommentOutput.getMessage();
        this.time = flowableQueryTaskCommentOutput.getTime();
    }
}
