package samsundot.flowablesdk.common.wab;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Accessors(chain = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorInfo {
    private String code;
    private String message;
    private String details;

    public ErrorInfo(String message) {
        this.message = message;
    }

    public ErrorInfo(String code, String message) {
        this.code = code;
        this.message = message;
    }
}
