package samsundot.flowablesdk.common.model.flowable;

import lombok.Data;
import lombok.experimental.Accessors;

@Accessors(chain = true)
@Data
public class FlowableQueryTaskPagedInput {
    /// <summary>
    /// 起始数
    /// </summary>
    private int start ;

    /// <summary>
    /// 每页数量
    /// </summary>
    private int size ;

    /// <summary>
    /// 用户名
    /// </summary>
    private String  assignee ;

    /// <summary>
    /// 流程Key
    /// </summary>
    private String processDefinitionKey ;
}
